# UAT Scenarios — Per Role & Per Batch

## Tujuan
Dokumen ini mendefinisikan skenario uji minimum agar proyek tidak terasa "selesai" hanya karena build hijau.

---

## 1. Batch 0 Stabilization UAT

### 1.1 Renew Modal
- buka stay ACTIVE yang punya planned checkout valid
- buka renew modal -> tidak crash
- buka stay tanpa planned checkout -> tidak crash
- ubah tanggal valid -> submit bekerja / error operasional tampil wajar

### 1.2 Save Notes Stay
- buka stay detail
- ubah notes
- simpan -> tidak 404
- refresh -> notes tetap tersimpan

### 1.3 Renew Open-Ended Stay
- perpanjang stay open-ended
- cek invoice renewal period
- pastikan period start tidak lompat ke masa lalu yang salah

### 1.4 Meter Refresh
- tambah meter reading
- lihat tab meter -> data baru langsung muncul tanpa manual refresh

### 1.5 Enum Inputs Check-in
- pilih booking source & stay purpose valid
- submit valid -> sukses
- tidak ada lagi input bebas yang menghasilkan 400 enum

### 1.6 Dashboard Guard
- login sebagai tenant
- ketik `/dashboard` manual
- tenant tidak melihat dashboard admin/backoffice
- tenant diarahkan ke route portal yang aman

### 1.7 Login Hygiene
- buka halaman login
- email dan password default kosong
- tidak ada kredensial yang diprefill

### 1.8 Tenant Page Honesty
- buka tenant stay page saat memang tidak punya stay aktif -> empty state ramah
- buka tenant stay page saat backend error -> error state operasional tampil, bukan no-data palsu
- buka tenant announcements dengan payload tidak ideal -> page tidak crash

---

## 2. Phase B — Tenant Portal Access UAT

### 2.1 Portal Summary
- buka tenant detail yang sudah punya akun portal
- portal email tampil
- status aktif/nonaktif tampil
- last login tampil jika ada
- tidak ada relasi mentah yang membingungkan operator

### 2.2 Email Simplification
- buka create/edit tenant
- email tenant vs email portal tidak terasa seperti dua input setara tanpa konteks
- wording operasional lebih jelas
- UI tidak mengklaim portal otomatis dibuat jika memang belum

### 2.3 Create Portal Account
- login sebagai owner/admin
- buka tenant yang belum punya akun portal
- CTA "Buat Akun Portal" muncul
- submit email + password valid -> sukses
- tenant context refresh dan portal summary muncul
- tenant yang sudah punya portal tidak lagi menampilkan CTA create

### 2.4 Toggle Portal Access
- login sebagai owner/admin
- buka tenant yang sudah punya akun portal
- toggle aktif/nonaktif portal
- loading state muncul
- sukses/error feedback tampil wajar
- status portal refresh setelah aksi
- role non-authorized tidak melihat CTA toggle

### 2.5 Reset Password Portal
- login sebagai owner/admin
- buka tenant yang sudah punya akun portal
- CTA reset password muncul
- password baru minimal 8 karakter
- submit valid -> sukses
- feedback tampil jelas
- tenant tanpa portal tidak melihat CTA reset

---

## 3. Owner UAT
- login sebagai owner
- landing ke dashboard strategis
- tidak melihat surface admin penuh sebagai default utama
- bisa melihat KPI utama
- bisa melihat report ringkas
- bisa melihat atau mengelola portal access tenant bila perlu

---

## 4. Admin UAT
- login sebagai admin
- landing ke dashboard operasional
- check-in, renew, checkout masih masuk akal
- bisa mengelola tenants/rooms
- bisa melihat approval/payment area existing yang relevan
- bisa create/toggle/reset portal access tenant dari tenant context

---

## 5. Staff UAT
- login sebagai staff
- hanya melihat menu teknis yang relevan
- fokus ke tickets/inventory/rooms yang memang kontekstual
- tidak melihat CTA manajerial yang tidak perlu
- tidak melihat CTA portal access tenant

---

## 6. Tenant UAT
- login sebagai tenant
- melihat stay sendiri
- melihat invoice sendiri
- tiket sendiri mudah dibuat/dilihat
- tidak diminta input ID manual
- tidak bisa mengakses route backoffice yang tidak relevan

---

## 7. Payment Approval UAT (vNext nanti)
- invoice diterbitkan
- tenant submit bukti bayar
- admin melihat queue
- admin approve/reject
- tenant melihat status

---

## 8. Acceptance Rule
Skenario dianggap lolos jika:
1. happy path berjalan
2. empty/loading/error state tidak menyesatkan
3. role tidak melihat CTA yang salah
4. data setelah aksi terlihat sinkron tanpa refresh manual yang tidak wajar
5. tenant portal tetap sederhana dan tidak bocor ke surface backoffice
