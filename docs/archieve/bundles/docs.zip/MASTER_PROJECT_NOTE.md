# KOST48 SURABAYA V3 — MASTER PROJECT NOTE (Synced Rewrite)

## 1. Tujuan Dokumen
Dokumen ini adalah pusat kendali lengkap proyek KOST48 V3 setelah:
- baseline existing diverifikasi sebagian,
- beberapa docs lama saling bertabrakan,
- audit backend/frontend menunjukkan blocker nyata,
- arah produk bergeser ke role-based restructure.

Dokumen ini bertujuan membuat semua sesi kerja membaca proyek dari sudut pandang yang sama:
1. **apa yang tetap dipertahankan,**
2. **apa yang sedang rusak atau belum lengkap,**
3. **apa yang harus dikerjakan dulu,**
4. **apa arah jangka berikutnya.**

---

## 2. Identitas Proyek

| Item | Nilai |
|------|-------|
| Nama | WebKost48 Surabaya V3 |
| Model bisnis | Hybrid kos–hospitality |
| Developer | Solo developer |
| Struktur repo | Monorepo sederhana |
| Backend | NestJS + Prisma |
| Database | PostgreSQL |
| Frontend | React + Vite + TS + React-Bootstrap |
| App aktif | Backoffice + Tenant Portal dasar |
| Environment default | Windows + VS Code + PowerShell |

---

## 3. Prinsip Arsitektur yang Tidak Ditawar
1. Satu backend modular
2. Satu database PostgreSQL
3. Satu Prisma schema
4. Tidak ada microservices
5. Constraint bisnis penting tetap dibantu trigger/constraint DB
6. Semua operasi multi-entity penting tetap atomik

---

## 4. Cara Membaca Proyek Saat Ini

### Lapis A — Existing Baseline
Ini adalah fondasi yang tidak boleh dirusak sembarangan:
- single active stay
- room sync
- checkout berarti tenant keluar
- deposit terpisah
- meter awal atomik
- overpay guard
- invoice total recalc existing

### Lapis B — Stabilization Layer
Ini adalah kumpulan bug/gap nyata yang harus ditutup dulu agar fondasi tadi benar-benar bisa dipercaya dipakai untuk redesign.

### Lapis C — Role-Based Restructure
Ini adalah arah produk besar berikutnya:
- Owner surface
- Admin surface
- Staff surface
- Tenant surface
- tenant identity simplification
- ticket tenant-only
- compact IA
- approval payment flow
- owner dashboards

---

## 5. Fondasi Existing yang Tetap Berlaku

### 5.1 Stay & Room
- satu tenant hanya boleh punya satu stay aktif
- satu room hanya boleh punya satu stay aktif
- room status harus sinkron dengan stay aktif
- backoffice create stay langsung aktif
- checkout berarti tenant benar-benar keluar
- room bisa kembali AVAILABLE bila tidak ada stay aktif lain

### 5.2 Deposit
- deposit tidak diputuskan saat checkout
- deposit diproses terpisah
- process deposit diblok jika ada invoice `ISSUED` / `PARTIAL`
- jangan membaca deposit hanya dari wording teknis UI

### 5.3 Meter
- meter awal wajib
- meter awal disimpan sebagai `MeterReading`, bukan field stay
- uniqueness dan monotonic tetap dijaga DB + service

### 5.4 Invoice & Payment
- invoice header adalah tagihan
- invoice line menyimpan rincian
- total invoice mengikuti recalc dari line
- payment admin langsung ke `InvoicePayment` tetap berlaku di baseline existing
- overpay tetap dilarang

### 5.5 Reminder
- reminder lifecycle saat ini hanya computed display ringan
- belum ada scheduler
- belum ada notification engine

---

## 6. Audit Synthesis — Apa yang Sudah Jelas

### 6.1 Backend
Audit backend menunjukkan:
- fondasi DB kuat
- happy path inti umumnya berjalan
- ada gap endpoint dan beberapa bug logic yang tidak boleh diabaikan

Temuan kunci:
1. `PATCH /stays/:id` belum ada
2. `renewStay` bermasalah untuk stay open-ended
3. validasi `ProcessDepositDto.action` terlalu longgar
4. ticket number generation rawan race
5. `findOne` stay belum selaras dengan `findAll` untuk `openInvoiceCount`
6. `cancel` belum menyimpan `cancelReason`

### 6.2 Frontend
Audit frontend menunjukkan:
- fondasi API layer dan auth cukup rapi
- ada bug integrasi yang menyebabkan data salah atau stale
- ada page tenant yang masih terlalu mirip backoffice

Temuan kunci:
1. cache key mismatch meter
2. free-text enum di check-in wizard
3. save notes stay memanggil endpoint backend yang tidak ada
4. FinanceTab paid summary tidak akurat
5. MeterTab membaca field meter awal yang sebenarnya tidak ada di backend stay
6. Process deposit belum mendukung FORFEIT
7. dashboard tidak diinvalidasi setelah aksi stay
8. MyTicketsPage masih alias TicketsPage backoffice
9. announcements tenant memakai endpoint yang belum pasti ada
10. tidak ada global 401 interceptor

---

## 7. Batch 0 — Stabilization

### 7.1 Tujuan
Menutup blocker yang memutus flow dasar sebelum role-based restructure besar dimulai.

### 7.2 Prinsip
- patch kecil
- file target sempit
- PowerShell default
- tidak membuka schema change besar
- tidak membuka redesign state besar
- uji minimum wajib

### 7.3 Daftar pekerjaan
#### P0
1. `CreateStayDto` ditambah field required:
   - `initialElectricityKwh`
   - `initialWaterM3`
2. `stays.service.ts` diperbarui agar create stay membuat 2 record `MeterReading` atomik dalam transaction yang sama
3. Validasi non-negatif dilakukan dengan `Prisma.Decimal`
4. Error handling untuk unique conflict dan monotonic trigger dibungkus ke pesan Indonesia
5. Build backend berhasil

**File yang diubah:**
1. `backend/src/modules/stays/dto/stay.dto.ts`
2. `backend/src/modules/stays/stays.service.ts`

**Hasil uji:**
- ✅ Create stay valid sukses
- ✅ Dua baseline meter reading tercipta
- ✅ Field meter awal wajib
- ✅ Nilai negatif ditolak
- ✅ Duplicate reading ditolak
- ✅ Monotonic violation ditolak
- ✅ Rollback transaction tetap aman bila create meter reading gagal

**Status:**
- ✅ Fase 3A-backend selesai
- ✅ Blocker initial meter backend ditutup
- ▶️ Lanjut ke penyelarasan frontend

---

### 2026-04-16 — Fase 3A-frontend Selesai: Meter Awal Wajib di Check-in Form
**Aktivitas:**
- Menyelaraskan check-in wizard dengan DTO backend baru yang mewajibkan dua meter awal.
- Fokus hanya pada UI check-in tanpa menyentuh backend lagi.

**Perbaikan utama:**
1. Field meter awal listrik dan air tampil jelas di wizard
2. Dua field dibuat required
3. Validasi:
   - wajib diisi
   - angka desimal valid
   - tidak boleh negatif
4. Payload submit mencakup:
   - `initialElectricityKwh`
   - `initialWaterM3`
   sebagai string
5. Error backend tetap tampil melalui `wizardError`

**File yang diubah:**
1. `frontend/src/types/index.ts`
2. `frontend/src/pages/stays/CheckInWizard.tsx`
3. `frontend/src/api/stays.ts` tetap kompatibel tanpa perlu perubahan besar

**Hasil uji:**
- ✅ Build frontend sukses
- ✅ Validasi frontend bekerja
- ✅ Submit valid sukses ke backend
- ✅ Frontend dan backend contract selaras

**Status:**
- ✅ Fase 3A-frontend selesai
- ✅ Check-in wizard sekarang selaras dengan backend baru
- ▶️ Siap untuk smoke test end-to-end

---

### 2026-04-16 — End-to-End Verification Sukses untuk Check-in + Initial Meter
**Aktivitas:**
- Melakukan verifikasi manual end-to-end setelah Fase 3A-backend dan Fase 3A-frontend selesai.

**Yang diverifikasi:**
1. Frontend menolak field meter kosong
2. Frontend menolak nilai negatif
3. Frontend menolak input non-numeric
4. Submit valid menghasilkan create stay sukses
5. Backend menyimpan 2 baseline meter reading
6. Flow utama stays tetap aman

**Status:**
- ✅ End-to-end verification sukses
- ✅ Blocker lama initial meter resmi dianggap tertutup

---

### 2026-04-16 — Fase 2 Selesai: Checkout UX Hardening
**Aktivitas:**
- Menguatkan UX checkout pada stay detail agar lebih aman untuk operasional harian.
- Fokus pada modal konfirmasi, alasan checkout wajib, dan hint deposit terpisah.

**Perbaikan utama:**
1. Tombol utama stay detail memakai label **Checkout**
2. Modal checkout memakai Bahasa Indonesia penuh
3. `checkoutReason` wajib diisi
4. Ditambahkan hint jelas bahwa deposit diproses terpisah setelah checkout
5. Flow deposit tetap dipisah dari checkout

**File yang diubah:**
1. `frontend/src/components/stays/CompleteStayModal.tsx`
2. `frontend/src/components/stays/InfoTab.tsx`
3. `frontend/src/pages/stays/StayDetailPage.tsx` tetap kompatibel dengan flow baru

**Hasil uji:**
- ✅ Build frontend sukses
- ✅ Modal checkout muncul dengan benar
- ✅ Validasi alasan checkout bekerja
- ✅ Hint deposit terlihat jelas
- ✅ Tidak ada redesign deposit yang melebar

**Status:**
- ✅ Fase 2 selesai
- ✅ Checkout UX lebih aman dan lebih jelas secara operasional

---

### 2026-04-17 — Fase 3B ACT 1 Selesai: Dashboard Reminder Harian
**Aktivitas:**
- Mengimplementasikan reminder lifecycle ringan di dashboard sebagai computed display frontend-only.
- Tetap dalam batas plan: tanpa backend baru, tanpa scheduler, tanpa placeholder palsu.

**Reminder yang ditampilkan:**
1. **H-10 — Masa Tinggal Akan Habis**
2. **H-3 — Tagihan Akan Jatuh Tempo**

**Reminder yang ditunda:**
- H-7 — Persiapan Meter & Invoice
- H+1 — Deposit Perlu Diproses

**File yang diubah:**
- `frontend/src/pages/dashboard/DashboardPage.tsx`

**Hasil uji:**
- ✅ Section "Reminder Harian" tampil
- ✅ H-10 tampil untuk stay aktif yang mendekati planned checkout
- ✅ H-3 tampil untuk invoice yang mendekati due date
- ✅ Empty state tetap rapi

**Status:**
- ✅ Fase 3B ACT 1 selesai
- ▶️ Lanjut ke reminder badge di stays list

---

### 2026-04-17 — Fase 3B ACT 2 Selesai: Reminder Badge di Stays List
**Aktivitas:**
- Menambahkan badge reminder ringan di stays list untuk stay aktif yang mendekati planned checkout.

**Logic badge final:**
- `H-10` → 8–10 hari sebelum checkout
- `H-7` → 4–7 hari sebelum checkout
- `H-3` → 0–3 hari sebelum checkout
- Hanya untuk stay `ACTIVE`
- Tidak tampil jika `plannedCheckOutDate` kosong/invalid

**File yang diubah:**
- `frontend/src/pages/stays/StaysPage.tsx`

**Hasil uji:**
- ✅ Stay ACTIVE dengan planned checkout dekat menampilkan badge
- ✅ Stay tanpa planned checkout tidak menampilkan badge
- ✅ Stay non-ACTIVE tidak menampilkan badge reminder
- ✅ Layout list tetap rapi

**Status:**
- ✅ Fase 3B ACT 2 selesai
- ▶️ Lanjut ke due soon badge di invoices list

---

### 2026-04-17 — Fase 3B ACT 3 Selesai: Due Soon Badge di Invoices List
**Aktivitas:**
- Menambahkan due soon badge ringan di invoices list untuk membantu prioritas penagihan.

**Logic badge final:**
- `Hari Ini` → due date hari ini
- `Besok` → due date besok
- `H-3` → due date 2–3 hari lagi
- Hanya untuk invoice `ISSUED` / `PARTIAL`
- Tidak tampil untuk `PAID`, `CANCELLED`, `DRAFT`, atau due date kosong/invalid

**File yang diubah:**
- `frontend/src/pages/invoices/InvoicesPage.tsx`

**Hasil uji:**
- ✅ Invoice ISSUED/PARTIAL dengan due date dekat menampilkan badge
- ✅ Invoice status lain tidak menampilkan badge
- ✅ Invoice tanpa due date tidak menampilkan badge
- ✅ Layout invoices list tetap rapi

**Status:**
- ✅ Fase 3B ACT 3 selesai
- ✅ Paket reminder lifecycle ringan frontend-only selesai

---

### 2026-04-17 — Freeze Sementara Hasil Core Flow Stays + Reminder Ringan
**Aktivitas:**
- Menyimpulkan fase aktif yang sudah selesai dan menyiapkan proyek untuk PLAN berikutnya dengan konteks yang lebih bersih.

**Ringkasan hasil yang sudah verified:**
1. Fase 1 — Audit stays UX selesai
2. Fase 2 — Checkout UX hardening selesai
3. Fase 3A-backend — atomic initial meter selesai
4. Fase 3A-frontend — meter awal wajib selesai
5. Fase 3B ACT 1–3 — reminder lifecycle ringan selesai

**Batasan yang tetap dipertahankan:**
- scheduler reminder otomatis belum dibangun
- debt flow tetap ditunda
- anomaly `PENDING` tetap backlog
- H-7 meter-aware reminder dan H+1 deposit follow-up tetap ditunda sampai ada PLAN baru

**Status:**
- ✅ Core flow stays untuk fase ini stabil
- ✅ Reminder lifecycle ringan frontend-only selesai
- ▶️ Menunggu keputusan user untuk PLAN berikutnya

---

### 2026-04-17 — PLAN Deposit Queue Disetujui + ACT 1 Backend Read-only Selesai
**Aktivitas:**
- Melakukan audit tambahan terhadap docs aktif dan codebase sebelum membuka slice baru.
- Menetapkan bahwa langkah berikutnya harus berupa **Post-Checkout Follow-up / Deposit Queue** yang bersifat read-only, bukan redesign flow stay/invoice.
- Menyelesaikan **ACT 1 backend** untuk mendukung data antrian deposit di dashboard.

**Temuan audit yang mempengaruhi arah slice:**
1. Flow `PENDING` masih hidup di backend dan frontend, sehingga tidak aman membuka redesign state model stay.
2. Deposit queue harus diposisikan sebagai **antrian operasional backoffice**, bukan reminder H+1 otomatis.
3. Slice berikutnya harus dijaga tetap kecil, read-only, dan tidak menyentuh debt flow, scheduler, atau invoice generation besar.

**Perbaikan backend yang selesai:**
1. `GET /stays` ditambah dukungan filter `depositStatus`.
2. Hasil list stay ditambah field computed `openInvoiceCount`.
3. `openInvoiceCount` menghitung invoice dengan status `ISSUED` atau `PARTIAL`.
4. Perubahan tetap read-only dan tidak mengubah schema, bootstrap SQL, controller, maupun flow transaksi inti.

**File yang diubah:**
1. `backend/src/modules/stays/dto/stays-query.dto.ts`
2. `backend/src/modules/stays/stays.service.ts`

**Hasil verifikasi:**
- ✅ Build backend sukses
- ✅ Filter `depositStatus` tersedia untuk kebutuhan deposit queue
- ✅ Computed field `openInvoiceCount` tersedia di hasil list stay
- ✅ Tidak membuka backlog `PENDING`
- ✅ Tidak menambah endpoint baru
- ✅ Tidak mengubah behavior create / activate / complete / cancel / process deposit

**Keputusan lanjutan:**
- Deposit queue akan ditampilkan sebagai **section kecil “Antrian Deposit”** di dashboard.
- Frontend nanti harus memakai **2 query terpisah**:
  - `depositStatus=HELD&status=COMPLETED`
  - `depositStatus=HELD&status=CANCELLED`
- Hasil digabung di frontend lalu dibagi menjadi:
  - **Siap Diproses**
  - **Tertahan — Masih Ada Tagihan**

**Status:**
- ✅ PLAN deposit queue disetujui
- ✅ ACT 1 backend read-only selesai dan verified
- ▶️ Siap lanjut ke ACT 2 frontend dashboard

---

### 2026-04-17 — Deposit Queue: PLAN Disetujui, Backend Read-only Selesai, Frontend Dashboard Selesai
**Aktivitas:**
- Melakukan audit tambahan terhadap docs aktif dan codebase sebelum membuka slice baru.
- Menetapkan bahwa langkah berikutnya harus berupa **Post-Checkout Follow-up / Deposit Queue** yang bersifat read-only.
- Menyelesaikan implementasi backend kecil untuk mendukung query deposit queue.
- Menyelesaikan implementasi frontend kecil untuk menampilkan **Antrian Deposit** di dashboard.

**Alasan slice ini dipilih:**
1. Deposit tetap diproses terpisah setelah checkout.
2. H+1 reminder otomatis masih ditunda, sehingga kebutuhan saat ini lebih cocok diwujudkan sebagai **antrian operasional backoffice**.
3. Codebase masih memiliki flow `PENDING`, sehingga slice baru harus dijaga tetap kecil dan tidak menyentuh redesign state model stay.

**Constraint yang tetap dijaga:**
- tidak membuka debt flow
- tidak membuka scheduler / notification engine
- tidak membuka anomaly `PENDING`
- tidak mengubah schema.prisma
- tidak mengubah bootstrap.sql
- tidak redesign invoice generation
- tidak redesign state transition stay

#### ACT 1 — Backend Read-only Deposit Queue Support
**Perbaikan utama:**
1. `GET /stays` ditambah dukungan filter `depositStatus`
2. hasil list stay ditambah field computed `openInvoiceCount`
3. `openInvoiceCount` menghitung invoice dengan status `ISSUED` atau `PARTIAL`
4. perubahan tetap read-only dan tidak mengubah flow transaksi inti

**File yang diubah:**
1. `backend/src/modules/stays/dto/stays-query.dto.ts`
2. `backend/src/modules/stays/stays.service.ts`

**Hasil verifikasi:**
- ✅ Build backend sukses
- ✅ Tidak menambah endpoint baru
- ✅ Tidak mengubah controller
- ✅ Tidak membuka flow `PENDING`
- ✅ Tidak mengubah behavior create / activate / complete / cancel / process deposit

#### ACT 2 — Frontend Dashboard “Antrian Deposit”
**Perbaikan utama:**
1. Dashboard memakai 2 query terpisah:
   - `depositStatus=HELD&status=COMPLETED`
   - `depositStatus=HELD&status=CANCELLED`
2. hasil digabung di frontend
3. item dibagi menjadi:
   - **Siap Diproses**
   - **Tertahan — Masih Ada Tagihan**
4. item menampilkan:
   - nama tenant
   - kamar
   - tanggal checkout / cancel
   - nominal deposit
   - status singkat
   - link ke detail stay / finance
5. empty state rapi ditampilkan bila queue kosong

**File yang diubah:**
1. `frontend/src/types/index.ts`
2. `frontend/src/pages/dashboard/DashboardPage.tsx`

**Hasil verifikasi:**
- ✅ Build frontend sukses
- ✅ Tetap dashboard-only
- ✅ Tidak membuka backlog besar
- ⏳ Menunggu smoke test runtime singkat untuk verifikasi final

**Status saat ini:**
- ✅ PLAN deposit queue disetujui
- ✅ ACT 1 backend selesai
- ✅ ACT 2 frontend selesai
- ▶️ Menunggu smoke test runtime dan freeze kecil untuk slice Deposit Queue

---

### 2026-04-17 — Reopen Terbatas: Check-in Wizard Eligibility Runtime Belum Final
**Aktivitas:**
- Melakukan audit ulang terhadap hasil patch eligibility wizard karena build sukses tidak sama dengan runtime benar.
- Fokus dipersempit hanya pada flow check-in wizard, tanpa membuka ulang modul lain.

**Temuan lapangan terbaru:**
1. Patch sebelumnya sempat diklaim menutup bug eligibility runtime
2. Namun verifikasi lapangan menunjukkan hasil belum final:
   - sebelumnya tenant tidak eligible masih bisa muncul
   - setelah patch lanjutan, muncul indikasi over-blocking
   - tenant dengan stay historis `COMPLETED` bisa ikut terblokir
   - bahkan ada kemungkinan dropdown tenant kosong / tidak memuat semua tenant
3. Ini berarti fix sebelumnya belum boleh di-freeze sebagai runtime success

**Klarifikasi boundary final yang ditegaskan ulang:**
1. Yang diblok di wizard hanya tenant dengan stay `ACTIVE`
2. Tenant dengan stay historis `COMPLETED` / `CANCELLED` harus tetap boleh check-in lagi
3. `PENDING` tetap diisolasi dari flow backoffice aktif dan tidak boleh diam-diam dijadikan blocker baru tanpa PLAN besar
4. Evaluasi fix wizard harus berbasis smoke test runtime manual, bukan build saja

**Keputusan operasional sesi ini:**
- Sebelum patch ACT baru, perlu dilakukan **PLAN audit runtime**
- Audit harus menelusuri:
  - alur data tenant dropdown
  - alur data room dropdown
  - kemungkinan stale options di `SearchableSelect`
  - kemungkinan loading guard membuat dropdown kosong
  - kemungkinan query blocker eligibility tidak sesuai boundary final

**Status:**
- ✅ Core flow stays lain tetap stabil
- ⚠️ Wizard eligibility runtime belum final
- ▶️ Next step resmi: PLAN audit frontend wizard sebelum ACT baru

---

### 2026-04-17 — Check-in Wizard Eligibility Ditutup + Handoff ke PLAN Baru
**Aktivitas:**
- Menutup rangkaian hardening runtime untuk Check-in Wizard tenant dropdown.
- Fokus sebelumnya adalah memastikan:
  - tenant dengan stay `ACTIVE` tidak selectable
  - tenant historis tetap selectable lagi
  - dropdown tenant tidak kosong saat pertama dibuka
  - default options tenant muncul tanpa harus mengetik dulu

**Perbaikan final yang berhasil ditutup:**
1. `SearchableSelect` diperbarui agar mendukung preload/default options
2. `CheckInWizard` diperbarui agar memuat default tenant options setelah blocker aktif siap
3. Filter eligibility tenant tetap berbasis `ACTIVE` saja
4. Error/loading state pada step tenant tetap dijaga

**File code terakhir yang terkait penutupan slice ini:**
1. `frontend/src/components/common/SearchableSelect.tsx`
2. `frontend/src/pages/stays/CheckInWizard.tsx`

**Status:**
- ✅ Wizard eligibility runtime dianggap cukup stabil untuk ditutup
- ✅ Fokus aktif berpindah dari bug wizard ke PLAN vertical slice baru

---

### 2026-04-17 — Kandidat PLAN Baru: Commercial Entry Flow, Deposit Payment, Renewal, dan List Consistency
**Aktivitas:**
- Mengelompokkan masalah baru yang muncul setelah wizard selesai.
- Menetapkan bahwa masalah berikutnya tidak cocok dikerjakan sebagai ACT kecil tunggal, tetapi perlu PLAN baru.

**Kelompok masalah baru:**
1. **Semantik invoice awal & deposit**
   - `depositStatus = HELD` tidak boleh otomatis saat stay dibuat
   - deposit harus benar-benar dibayar dulu sebelum dianggap held
   - invoice pertama perlu menekankan status belum bayar
2. **Flow pembayaran**
   - input total tagihan
   - input jumlah transfer tenant
   - rule kurang bayar / partial
   - rule lebih bayar / overpayment
3. **UI clarity & warning**
   - banner unpaid
   - badge metered tidak jelas
   - semua nominal invoice harus format Rupiah
4. **List consistency**
   - check-in di stays list masih bisa `-`
   - `period` / `due` di invoices list masih bisa `-`
   - invoice list perlu filter yang lebih konsisten
5. **Renewal / perpanjangan stay**
   - kemungkinan tombol manual
   - kemungkinan terhubung reminder H-10 / H-7 / H-3
   - kemungkinan bayar di muka untuk perpanjangan

**Keputusan operasional sesi ini:**
- Next step resmi untuk chat berikutnya adalah **PLAN**, bukan ACT
- PLAN harus membagi masalah di atas menjadi vertical slice yang aman dan kecil
- Jangan membuka debt flow, scheduler, atau redesign state model besar

**Status:**
- ✅ Wizard runtime slice selesai
- ▶️ Next step resmi: PLAN commercial entry flow

### 2026-04-17 — Commercial Entry Freeze Selesai + ACT 1 Display Consistency Diterima
**Aktivitas:**
- Menutup PLAN commercial entry flow untuk fase aktif sekarang pada level yang cukup aman.
- Menerima hasil ACT 1 frontend untuk list consistency + clarity pada area stays/invoices.
- Menetapkan ACT berikutnya sebagai payment entry UX hardening.

**Keputusan freeze yang dipakai:**
1. Deposit payment proof di UI bersifat display-only, bukan perubahan schema
2. Overpay tetap dilarang mengikuti contract existing
3. Create stay tidak auto-generate invoice awal
4. Invoice awal dibuat manual oleh admin
5. Renewal = extend existing `ACTIVE` stay
6. Invoice renewal tetap manual oleh admin

**Hasil ACT 1 yang diterima:**
1. `frontend/src/pages/stays/StaysPage.tsx`
   - label status lebih jelas
   - deposit lebih fokus ke nominal Rupiah
   - fallback check-in aman
2. `frontend/src/pages/invoices/InvoicesPage.tsx`
   - filter status + search sederhana
   - label user-facing lebih konsisten
   - format Rupiah dan fallback tanggal/periode lebih aman
3. `frontend/src/pages/invoices/InvoiceDetailPage.tsx`
   - ringkasan invoice lebih jelas
   - tabel line lebih konsisten
   - label section pembayaran lebih rapi

**Hasil verifikasi:**
- ✅ Build frontend berhasil
- ✅ Tetap frontend-only
- ✅ Tidak mengubah contract backend
- ✅ Tidak membuka redesign besar
- ✅ ACT 1 dianggap selesai dan dibekukan

**Next step resmi:**
- ▶️ ACT 2 — Payment Entry UX Hardening di `InvoiceDetailPage.tsx`

### 2026-04-17 — ACT 2 Selesai: Payment Entry UX Hardening
**Aktivitas:**
- Menyelesaikan hardening UX input pembayaran di halaman detail invoice.
- Menambahkan ringkasan Total / Sudah Dibayar / Sisa Tagihan.
- Menambahkan preview nominal pembayaran dan blokir overpay di UI.
- Mengubah form pembayaran menjadi modal, form tambah rincian menjadi toggle.
- Menambahkan riwayat pembayaran dalam tabel.
- Menambahkan informasi Tenant dan Kamar di Ringkasan Invoice (backend disesuaikan dengan include relasi).

**File yang diubah:**
- `frontend/src/pages/invoices/InvoiceDetailPage.tsx`
- `backend/src/modules/invoices/invoices.service.ts` (include tenant & room)

**Status:**
- ✅ ACT 2 selesai dan dibekukan.
- ▶️ Lanjut ke ACT 3 — Unpaid Warning + Deposit Wording Clarity.
### 2026-04-17 — ACT 3 Selesai: Unpaid Warning + Deposit Wording Clarity
**Aktivitas:**
- Menyelesaikan hardening peringatan tagihan dan wording deposit di halaman detail stay.
- Menambahkan fungsi `hasUnpaidInvoices` untuk mendeteksi invoice ISSUED/PARTIAL.
- Menampilkan Alert jika ada tagihan belum lunas.
- Mengubah badge deposit dari sekadar `HELD` menjadi label deskriptif Bahasa Indonesia.

**File yang diubah:**
- `frontend/src/pages/stays/StayDetailPage.tsx`

**Hasil:**
- ✅ Build frontend berhasil.
- ✅ Tidak ada perubahan backend atau kontrak.
- ✅ Deposit wording lebih jelas, unpaid warning tampil sesuai kondisi.

**Status:**
- ✅ ACT 3 selesai dan dibekukan.
- ▶️ Menunggu PLAN selanjutnya.

### 2026-04-18 — Invoice Automation & Renew Flow Masuk Tahap Verify & Freeze
**Aktivitas:**
- Mengaudit implementasi baru yang melampaui freeze commercial entry lama.
- Menetapkan bahwa implementasi invoice automation dan renew flow tidak boleh langsung dianggap baseline final hanya karena sudah ada di codebase.
- Menempatkan fase ini pada status verify & freeze.

**Implementasi yang sudah diaudit dari code:**
1. `createStay`
   - create stay tetap atomik
   - membuat invoice awal `DRAFT`
   - membuat line `RENT`
   - `periodEnd` dihitung dari `pricingTerm` atau override `plannedCheckOutDate`
   - `dueDate = periodEnd + 3 hari`
2. `renewStay`
   - endpoint `POST /stays/:id/renew` ada
   - stay aktif diperpanjang
   - invoice renewal `DRAFT` dibuat otomatis
   - line `RENT` dibuat otomatis
3. frontend renew flow
   - tombol **Perpanjang Stay** ada
   - `RenewStayModal` ada
   - validasi tanggal baru ada
   - mutation renew ada
4. wording patch
   - unpaid warning sudah dibahasa-Indonesia-kan
   - wording deposit sudah dinetralkan

**Hasil audit penting:**
- ✅ Revisi ACT 1 lolos code audit
- ✅ ACT 2 backend renew flow lolos code audit
- ✅ ACT 3 frontend renew flow core ada
- ⏳ Helper API renew dan smoke test runtime penuh masih perlu verifikasi
- ⏳ Docs aktif masih perlu disinkronkan

**Status:**
- ▶️ Next step resmi: verification dan freeze docs


---

## 8. Update Sinkron 2026-04-20 — Freeze Phase B Core Portal Access

### Kesimpulan status terbaru
Setelah Phase A role split dianggap cukup berjalan, proyek masuk ke **Tenant Identity & Portal Access Simplification** dan core slice-nya sekarang dianggap cukup freeze-ready.

### Yang sudah tertutup di Phase B
1. tenant detail enriched dengan portal summary
2. email portal tidak terasa ganda di create/edit
3. honest portal visibility di tenant context
4. toggle portal access dari tenant context
5. create portal account dari tenant context
6. reset password portal dari tenant context

### Makna operasional
- operator kini dapat memahami relasi tenant ↔ user portal dari tenant context
- operator tidak perlu berpindah ke flow users generik untuk lifecycle dasar portal tenant
- role OWNER/ADMIN bisa mengelola portal access dasar tanpa membuka auth redesign besar
- tenant tetap tidak melihat surface backoffice

### Implikasi fokus berikutnya
Core portal access tidak lagi menjadi blocker utama.
**Next official phase** bergeser ke **Ticket Tenant-Only Redesign**:
- tenant menjadi sumber utama create ticket
- context tenant/stay/room harus makin auto-filled
- backoffice fokus assign/progress/close
