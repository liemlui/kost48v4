# Role & Permission Matrix — Draft Freeze

## Tujuan
Dokumen ini menerjemahkan arah role-based restructure menjadi matriks operasional yang bisa dipakai frontend, backend, dan docs planning.

---

## Prinsip Umum
1. Role memengaruhi menu, dashboard, CTA, dan hak aksi.
2. Hidden lebih baik daripada disabled jika menu sama sekali tidak relevan.
3. Jika role bisa melihat data tetapi tidak boleh mengubahnya, bedakan `read` dan `manage`.
4. Tenant portal harus paling sederhana.
5. Owner harus paling strategis, bukan paling operasional.

---

## Ringkasan per Role

| Area | Owner | Admin | Staff | Tenant |
|------|------|------|------|------|
| Dashboard strategis | Ya | Tidak utama | Tidak | Tidak |
| Dashboard operasional | Ringkasan saja | Ya | Versi teknis | Versi personal |
| Stays | Read summary | Manage | Tidak | My stay only |
| Rooms | Read summary | Manage | Contextual | Tidak |
| Tenants | Ringkasan + portal oversight | Manage | Tidak | Self only |
| Users | Manage ringan | Manage | Tidak | Tidak |
| Tickets | Ringkasan | Manage progress | Manage technical progress | Create & track own |
| Inventory | Summary | Manage | Manage technical | Tidak |
| Invoices | Finance summary | Manage + approval | Read contextual bila perlu | My invoices only |
| Payment approval | Summary only | Ya | Tidak | Tidak |
| Announcements | Manage | Manage | Read relevant | Read relevant |

---

## Owner

### Surface
- Dashboard Owner
- Laporan Keuangan & Analitik
- Users
- Announcements

### Allowed
- melihat KPI utama
- melihat billed / collected / overdue
- melihat occupancy summary
- melihat expense summary
- melihat ratios
- melihat report ringkas
- mengelola user level tinggi
- mengelola announcement
- melihat dan mengelola portal access tenant bila diperlukan

### Not primary
- check-in harian
- checkout harian
- edit meter harian
- create ticket operasional harian
- update progress ticket detail secara rutin

### Guideline UI
- sedikit CTA operasional
- lebih banyak cards, summaries, reports
- hindari tabel mentah panjang sebagai landing page utama

---

## Admin

### Surface
- Dashboard Admin
- Stays
- Rooms
- Tenants
- Invoices & Approval Pembayaran
- Tickets
- Announcements
- Users

### Allowed
- create stay / check-in
- update stay existing yang diizinkan
- checkout/cancel/process deposit
- renew stay
- manage rooms
- manage tenants
- manage portal access tenant
- create portal account tenant
- activate/deactivate portal access tenant
- reset password portal tenant
- create/edit/issue/cancel invoice draft sesuai rule
- create direct payment existing flow
- approve payment submissions vNext
- manage ticket lifecycle
- manage announcements
- manage users

### Not allowed as final target
- create ticket dari backoffice sebagai flow utama
- owner-only report editing
- debt override tanpa freeze baru

### Guideline UI
- operasional harian
- queue penting
- ringkasan tindak lanjut
- CTA jelas dan langsung

---

## Staff

### Surface
- Dashboard Staff
- Tickets
- Inventory
- Rooms (context terbatas)

### Allowed
- melihat ticket yang ditugaskan atau relevan
- update progress teknis
- update status kerja lapangan bila diizinkan
- melihat inventory
- melihat movement history
- melakukan aksi teknis terbatas yang relevan dengan tugas

### Tidak boleh
- check-in/checkout stay
- kelola tenant
- kelola users
- approval pembayaran
- process deposit
- create ticket backoffice sebagai sumber utama
- create/toggle/reset portal access tenant

### Guideline UI
- surface singkat
- fokus pekerjaan aktif
- low stock / tindakan teknis
- minim menu manajerial

---

## Tenant

### Surface
- Hunian Saya
- Tagihan Saya
- Tiket Saya
- Pengumuman

### Allowed
- melihat stay sendiri
- melihat invoice sendiri
- melihat status pembayaran/verifikasi sendiri
- submit payment proof pada target vNext
- create ticket sendiri
- melihat status tiket sendiri
- melihat pengumuman yang relevan
- melihat status akun portal sendiri bila nanti ditampilkan

### Tidak boleh
- input ID teknis manual
- create stay
- edit room
- approval payment
- manage tenant lain
- manage ticket orang lain
- create/toggle/reset portal access tenant lain

### Guideline UI
- sangat sederhana
- satu layar = satu kebutuhan utama
- bahasa non-teknis
- relasi auto-filled oleh context

---

## Permission Buckets

### Read-own
- tenant ke data sendiri

### Read-summary
- owner ke operasional summary

### Manage-ops
- admin ke flow operasional utama

### Manage-tech
- staff ke flow teknis yang ditugaskan

### Approve-finance
- admin ke approval pembayaran
- owner bisa summary/view dulu

### Manage-portal-access
- owner/admin ke create/toggle/reset portal access tenant

---

## Implikasi untuk Backend
1. role guard harus tetap jelas
2. endpoint tenant portal harus context-driven
3. endpoint approval payment harus admin-focused
4. ticket create endpoint tenant-first harus memanfaatkan auth context
5. portal access tenant harus tetap owner/admin only

---

## Implikasi untuk Frontend
1. layout role-aware
2. menu role-aware
3. dashboard role-aware
4. action button role-aware
5. page tenant harus berdiri sendiri, bukan alias page backoffice
6. action create/toggle/reset portal harus hidden untuk role yang tidak relevan
