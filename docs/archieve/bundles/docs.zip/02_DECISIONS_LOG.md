# Decisions Log — Synced Rewrite

Catatan keputusan arsitektur, workflow, dan freeze plan yang sudah dibekukan.
Entri lama yang masih relevan dipertahankan. Entri baru di bagian bawah menjadi penentu arah aktif.

---

## 2026-04-12 — Inisialisasi Proyek

### 1. Arsitektur Monorepo Sederhana
**Keputusan:** Backend dan frontend dalam satu folder root.  
**Alasan:** Solo developer, setup cepat, hemat tooling.  
**Dampak:** Struktur tetap `/backend`, `/frontend`, `/docs`.

### 2. Tidak Ada Tailwind CSS
**Keputusan:** UI memakai React-Bootstrap.  
**Alasan:** Cocok untuk backoffice cepat jadi.  
**Dampak:** Konsistensi komponen lebih mudah dijaga.

### 3. Constraint Database Dikelola di `bootstrap.sql`
**Keputusan:** Trigger, partial index, dan check constraint ditulis di SQL terpisah.  
**Alasan:** Prisma tidak menutup semua kebutuhan integritas.  
**Dampak:** Setiap reset DB harus ingat jalankan bootstrap SQL.

### 4. Vertical Slice Sebagai Strategi Utama
**Keputusan:** Kerjakan 1 flow kecil sampai verified sebelum pindah.  
**Alasan:** Menjaga fokus dan mengurangi drift konteks.  
**Dampak:** Hindari task lintas banyak modul sekaligus.

### 5. Testing Backend Wajib via Swagger/curl
**Keputusan:** Endpoint baru harus diuji sebelum frontend mengasumsikan selesai.  
**Alasan:** Mengurangi debug integrasi.  
**Dampak:** Build success saja tidak cukup.

---

## 2026-04-15 s.d. 2026-04-17 — Freeze Baseline Existing yang Tetap Berlaku

### 6. Checkout = Tenant Keluar Kos
**Keputusan:** Tidak ada physical checkout terpisah.  
**Dampak:** Flow checkout tetap sederhana.

### 7. Deposit Diproses Terpisah Setelah Checkout
**Keputusan:** Deposit bukan keputusan yang otomatis selesai saat checkout.  
**Dampak:** Perlu langkah proses deposit terpisah.

### 8. Debt Flow Ditunda
**Keputusan:** Debt/hutang tidak dibangun sekarang.  
**Dampak:** Tidak menambah status invoice baru untuk hutang.

### 9. Reminder Lifecycle Tetap PLAN-Only
**Keputusan:** Tidak ada scheduler/notifikasi otomatis.  
**Dampak:** Reminder ringan cukup computed display.

### 10. Meter Awal Harus Atomik di Create Stay
**Keputusan:** Meter awal wajib dicatat sebagai `MeterReading`, bukan field di `Stay`.  
**Dampak:** Create stay tetap transaksi multi-entity.

### 11. Anomali `PENDING` Masuk Backlog
**Keputusan:** `PENDING` tidak dibuka sebagai redesign state aktif sekarang.  
**Dampak:** Tetap dicatat sebagai high-risk backlog.

### 12. Meter Awal Wajib di Backend dan Frontend
**Keputusan:** Check-in tanpa dua meter awal dianggap invalid.  
**Dampak:** Validasi backend dan frontend sama-sama wajib.

### 13. Atomic Initial Meter Flow Dianggap Stabil
**Keputusan:** Flow create stay + baseline meter reading dianggap baseline existing.  
**Dampak:** Tidak boleh dibongkar tanpa blocker nyata.

### 14. Checkout UX Dengan Reason Wajib Dibekukan
**Keputusan:** Checkout frontend wajib pakai reason.  
**Dampak:** UX checkout tetap aman untuk operasional.

### 15. Reminder Lifecycle Fase Ini = Computed Display Ringan
**Keputusan:** Reminder tidak boleh berubah menjadi automation engine.  
**Dampak:** Dashboard/stays/invoices cukup badge dan section ringan.

### 16. Reminder Ditampilkan di Dashboard
**Keputusan:** Dashboard jadi titik utama visibilitas reminder.  
**Dampak:** Tidak perlu endpoint baru.

### 17. Reminder Stay Ditampilkan di Stays List
**Keputusan:** Badge reminder ringan di stays list dianggap cukup.  
**Dampak:** Tidak perlu flow baru.

### 18. Reminder Invoice Ditampilkan di Invoices List
**Keputusan:** Due-soon badge cukup untuk prioritas finansial ringan.  
**Dampak:** Tidak menambah enum baru.

### 19. H-7 Meter-Aware Reminder Ditunda
**Keputusan:** Data existing belum cukup untuk reminder H-7 yang kaya.  
**Dampak:** Tetap backlog plan-only.

### 20. H+1 Deposit Follow-up Ditunda
**Keputusan:** Follow-up deposit H+1 belum aman dibangun.  
**Dampak:** Deposit queue lebih aman daripada automation.

### 21. Tidak Ada Endpoint Baru untuk Reminder Ringan
**Keputusan:** Reminder cukup frontend-only.  
**Dampak:** Tidak membuka backend baru.

### 22. Environment Default = Windows PowerShell
**Keputusan:** Semua command default diasumsikan PowerShell.  
**Dampak:** Jangan lagi pakai Bash sebagai default prompt.

### 23. Deposit Payment Proof Fase Lama Bersifat Display-Only
**Keputusan:** Jangan baca `depositStatus` sendirian sebagai bukti pembayaran.  
**Dampak:** UI harus netral.

### 24. Overpay Tetap Dilarang
**Keputusan:** Total payment tetap tidak boleh melebihi total invoice.  
**Dampak:** Guard backend tetap dipertahankan.

### 25. Invoice Awal Tidak Auto-Generate di Freeze Lama
**Keputusan:** Ini berlaku di freeze lama, lalu disupersede sebagian oleh fase invoice automation.  
**Dampak:** Baca historis, bukan arah final.

### 26. Renewal = Extend Existing ACTIVE Stay
**Keputusan:** Renewal tidak boleh create parallel stay baru.  
**Dampak:** Tetap basis untuk flow renewal hingga sekarang.

### 27. Invoice Renewal Tetap Manual di Freeze Lama
**Keputusan:** Historis, lalu disupersede oleh fase invoice automation.  
**Dampak:** Dibaca sebagai jejak keputusan lama.

### 28. ACT 1 Display Consistency Diterima
### 29. ACT 2 Payment Entry UX Hardening Diterima
**Keputusan:** Patch kecil fase commercial entry lama diterima sebagai baseline existing.  
**Dampak:** Bisa dibaca sebagai fondasi, bukan fokus aktif baru.

---

## 2026-04-18 — Freeze Fase Invoice Automation (Tetap Diingat Sebagai Baseline Existing)

### 30. Create Stay Boleh Auto Membuat Invoice Awal `DRAFT`
**Keputusan:** Create stay boleh membuat invoice awal otomatis.  
**Dampak:** Manual invoice awal lama tidak lagi mutlak.

### 31. PeriodEnd dan DueDate Invoice Awal Dibakukan
**Keputusan:** `periodEnd` mengikuti `pricingTerm` atau override `plannedCheckOutDate`; `dueDate = periodEnd + 3 hari`.  
**Dampak:** Rule tanggal invoice awal jelas.

### 32. Renewal Boleh Auto Membuat Invoice Renewal `DRAFT`
**Keputusan:** Renewal boleh membuat invoice otomatis.  
**Dampak:** Tetap tidak auto-issue.

### 33. Total Invoice Tetap Mengikuti Recalc Existing
**Keputusan:** Service tidak boleh set total manual.  
**Dampak:** Semua automation harus hormati trigger/recalc.

### 34. Unit Line RENT Harus Mengikuti PricingTerm
**Keputusan:** Jangan hardcode bulan.  
**Dampak:** DAILY/WEEKLY/BIWEEKLY/MONTHLY/SMESTERLY/YEARLY tetap semantik benar.

### 35. Validasi Overlap Invoice Renewal Ditunda
**Keputusan:** Tidak dibangun di fase automation awal.  
**Dampak:** Renewal cukup validasi tanggal akhir baru lebih besar.

### 36. Wording Deposit di UI Tetap Netral
**Keputusan:** Jangan anggap `HELD` = sudah dibayar.  
**Dampak:** UI tetap hati-hati membaca deposit.

---

## 2026-04-18 — Sinkronisasi Baru: Batch 0 Stabilization + Role-Based Restructure

### 37. Fokus Aktif Bukan Rewrite Besar Sekaligus
**Keputusan:** Proyek tidak dikerjakan sebagai rewrite total satu batch, tetapi sebagai stabilization batch lalu ACT kecil bertahap.  
**Alasan:** Audit menunjukkan masih ada blocker runtime nyata.  
**Dampak:** Hindari klaim ZIP final sebagai baseline kode tanpa verifikasi bertahap.

### 38. Batch 0 Stabilization Menjadi Gate Wajib
**Keputusan:** Sebelum role-based restructure besar, blocker P0/P1 harus ditutup dulu.  
**Alasan:** Fondasi lama bernilai, tetapi belum cukup bersih untuk dijadikan basis redesign besar.  
**Dampak:** Bug runtime dan gap integrasi didahulukan.

### 39. `RenewStayModal` Invalid Date = P0 Pertama
**Keputusan:** Crash `Invalid time value` pada renew modal menjadi ACT teknis pertama yang paling aman.  
**Alasan:** Menjatuhkan halaman detail stay.  
**Dampak:** Semua helper date di area renew harus defensive.

### 40. Backend Gap `PATCH /stays/:id` Dianggap Blocker Existing
**Keputusan:** Endpoint update stay harus ada karena frontend sudah memanggilnya.  
**Alasan:** Fitur notes/save tidak boleh 404 diam-diam.  
**Dampak:** Batch stabilisasi harus menutup gap backend ini.

### 41. RenewStay Open-Ended Period Bug Wajib Ditutup
**Keputusan:** Bug period start renewal untuk stay tanpa `plannedCheckOutDate` dianggap blocker existing.  
**Alasan:** Menyebabkan invoice period salah secara bisnis.  
**Dampak:** Fix backend renewal masuk batch stabilisasi.

### 42. Meter Refresh Cache Mismatch Wajib Ditutup
**Keputusan:** Invalidasi meter reading yang salah key dianggap bug kritis frontend.  
**Alasan:** Data terlihat stale walau create reading sukses.  
**Dampak:** Hook/query key harus diselaraskan.

### 43. Enum Input Free-Text Tidak Boleh Dipertahankan
**Keputusan:** Field enum di check-in wizard harus memakai pilihan valid, bukan free-text.  
**Alasan:** Menghasilkan 400 backend yang seharusnya bisa dicegah di UI.  
**Dampak:** `bookingSource` dan `stayPurpose` harus select/dropdown.

### 44. Role-Based Product Surface Tetap Menjadi Arah Resmi Setelah Stabilization
**Keputusan:** Setelah Batch 0 cukup stabil, proyek lanjut ke Owner/Admin/Staff/Tenant surface yang berbeda.  
**Alasan:** IA lama terlalu gemuk dan bercampur.  
**Dampak:** Dashboard, menu, dan CTA harus dipisah per role.

### 45. Tenant dan User TENANT Harus Menjadi Satu Experience di UI
**Keputusan:** Data tenant dan portal access tenant harus terasa satu alur.  
**Alasan:** Email ganda dan relasi mentah membingungkan operasional.  
**Dampak:** Batch tenant identity menjadi bagian inti restructure.

### 46. Create Ticket Harus Tenant-First
**Keputusan:** Ticket dibuat tenant dari portal; backoffice fokus progress/assign/close.  
**Alasan:** Sumber tiket paling logis berasal dari tenant.  
**Dampak:** Form create ticket backoffice masuk backlog penghapusan/perubahan.

### 47. Meter Readings, Room Items, dan Inventory Movements Bukan Menu Utama
**Keputusan:** Modul-modul itu harus di-embed ke context yang lebih natural.  
**Alasan:** Menu utama saat ini terlalu gemuk.  
**Dampak:** IA baru wajib compact.

### 48. Invoice dan Payment Akan Bergerak ke Approval Flow vNext
**Keputusan:** Arah produk jangka berikutnya adalah invoice → submit bukti bayar → approval admin → status final.  
**Alasan:** Lebih sesuai operasional nyata.  
**Dampak:** Butuh API vNext baru; jangan diasumsikan sudah ada di codebase existing.

### 49. Owner Dashboard Bersifat Strategis
**Keputusan:** Owner tidak memakai surface operasional mentah seperti admin.  
**Alasan:** Owner butuh KPI, report ringkas, ratio, dan insight keputusan.  
**Dampak:** Owner dashboard jadi phase tersendiri.

### 50. Semua ACT Selanjutnya Harus Mengikuti Urutan Stabilization → Restructure
**Keputusan:** Jangan lompat ke fitur besar sebelum batch stabilisasi cukup tertutup.  
**Alasan:** Mengurangi regression dan false progress.  
**Dampak:** Roadmap resmi dibaca berlapis.

## 2026-04-19 — Freeze Frontend Stabilization Lanjutan + Role Split Inti

### 51. Tenant Tidak Boleh Masuk ke Dashboard Backoffice
**Keputusan:** Route `/dashboard` hanya untuk OWNER / ADMIN / STAFF.  
**Alasan:** Tenant portal harus sederhana dan tidak boleh jatuh ke surface admin.  
**Dampak:** Guard route dan fallback dashboard harus role-aware.

### 52. Login Tidak Boleh Prefill Kredensial
**Keputusan:** Form login harus kosong saat pertama dibuka.  
**Alasan:** Mengurangi risiko hygiene buruk dan menghindari kredensial demo/semu terlihat sebagai default.  
**Dampak:** `LoginPage` tidak lagi memprefill email/password.

### 53. Dashboard Invalidation Harus Mengikuti Prefix Dashboard
**Keputusan:** Invalidation dashboard setelah aksi stay memakai pendekatan prefix/predicate, bukan key generik yang tidak efektif.  
**Alasan:** Dashboard owner/admin/staff memakai query key yang berbeda.  
**Dampak:** Refresh dashboard lintas role lebih konsisten setelah check-in/aksi stay.

### 54. Tenant Pages Harus Jujur Soal Empty vs Error
**Keputusan:** Tenant portal tidak boleh menyamakan semua error sebagai no-data.  
**Alasan:** UX harus jujur dan tidak menyesatkan user.  
**Dampak:** Page seperti `MyStayPage`, `MyAnnouncementsPage`, dan area tenant lain wajib defensive.

### 55. Paid Summary Frontend Harus Defensif
**Keputusan:** Paid summary di frontend boleh bersifat netral bila payload tidak cukup kaya.  
**Alasan:** Lebih baik jujur daripada menampilkan angka yang terlihat final tetapi salah.  
**Dampak:** `FinanceTab` dan page terkait harus memakai fallback netral bila sumber data tidak cukup.

### 56. MyTicketsPage Harus Berdiri Sendiri
**Keputusan:** Page ticket tenant tidak boleh sekadar alias TicketsPage backoffice.  
**Alasan:** Tenant membutuhkan surface yang sederhana dan context-driven.  
**Dampak:** `MyTicketsPage` dibaca sebagai page tenant mandiri.

### 57. Meter Readings, Room Items, dan Inventory Movements Bukan Surface Utama
**Keputusan:** Modul-modul ini harus makin embedded/contextual dan tidak didorong sebagai menu utama generic CRUD.  
**Alasan:** IA baru harus compact over clutter.  
**Dampak:** Navigation dan resource config harus makin netral terhadap modul-modul teknis kecil ini.

### 58. Phase Aktif Berikutnya = Tenant Identity & Portal Access Simplification
**Keputusan:** Setelah Batch 0 frontend dan role split inti cukup tertutup, phase berikutnya adalah penyederhanaan tenant identity dan portal access.  
**Alasan:** Email portal ganda dan relasi tenant-user masih membingungkan operasional.  
**Dampak:** Fokus frontend berikutnya bergeser dari bug hardening ke tenant + portal summary.


## 2026-04-20 — Freeze Phase B Core Portal Access Slice

### 59. Tenant Detail Harus Menampilkan Portal Summary
**Keputusan:** Tenant detail/read context harus menampilkan ringkasan portal user secara langsung.  
**Alasan:** Operator perlu memahami relasi tenant ↔ portal tanpa membuka modul user generik.  
**Dampak:** `portalUserSummary` menjadi data penting di tenant context.

### 60. Email Portal Tidak Boleh Terasa Ganda
**Keputusan:** Create/edit tenant harus memakai wording yang memisahkan email kontak tenant vs email login portal secara human-readable.  
**Alasan:** Operator bingung jika dua email terlihat seperti input setara tanpa konteks.  
**Dampak:** UX tenant form harus jujur dan compact.

### 61. Honest Portal Visibility Mengalahkan Fake Toggle
**Keputusan:** Sebelum endpoint toggle aman tersedia, UI harus menampilkan visibility portal yang jujur dan tidak memberi kesan action sudah live.  
**Alasan:** Honest UX lebih penting daripada affordance palsu.  
**Dampak:** Portal status visibility dibenahi dulu sebelum toggle nyata dibuka.

### 62. Toggle Portal Access Harus Tenant-Context
**Keputusan:** Aktivasi/nonaktivasi portal tenant tidak boleh memakai flow final generic `PATCH /users/:id` dari frontend.  
**Alasan:** Tenant-context lebih aman, lebih jelas, dan lebih konsisten dengan relasi bisnis.  
**Dampak:** Dibuat endpoint khusus `PATCH /tenants/:id/portal-access/status`.

### 63. Create Portal Account Harus Tenant-Context
**Keputusan:** Pembuatan akun portal tenant tidak dibaca sebagai flow users generik, tetapi sebagai action dari tenant context.  
**Alasan:** Tenant dan user TENANT harus terasa satu experience.  
**Dampak:** Dibuat endpoint `POST /tenants/:id/portal-access`.

### 64. Reset Password Portal Dibuka Sebagai Slice Kecil Terpisah
**Keputusan:** Reset password portal tenant dibuka sebagai slice tenant-context terpisah, bukan forgot-password flow global.  
**Alasan:** Scope harus tetap kecil dan operasional-friendly.  
**Dampak:** Dibuat endpoint `POST /tenants/:id/portal-access/reset-password`.

### 65. Phase B Core Portal Access Dianggap Cukup Freeze-Ready
**Keputusan:** Setelah portal summary, email simplification, honest visibility, toggle, create portal account, dan reset password selesai, Phase B core slice dianggap cukup tertutup.  
**Alasan:** Tujuan inti penyederhanaan tenant identity & portal access sudah terpenuhi secara operasional.  
**Dampak:** Fokus resmi dapat berpindah ke phase berikutnya.

### 66. Next Official Phase = Ticket Tenant-Only Redesign
**Keputusan:** Setelah Phase B core freeze-ready, langkah resmi berikutnya adalah Phase C / Ticket Tenant-Only Redesign.  
**Alasan:** Roadmap dan role matrix sama-sama menekankan ticket sebagai flow tenant-first berikutnya.  
**Dampak:** Prompt PLAN/ACT selanjutnya harus membaca ticket tenant-first sebagai fokus baru.
