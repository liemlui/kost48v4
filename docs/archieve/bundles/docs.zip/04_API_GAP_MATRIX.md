# API Gap Matrix — Existing vs Target vNext

## Tujuan
Dokumen ini memetakan:
- API yang sudah ada di baseline existing
- API yang perlu diperkaya
- API yang belum ada tetapi dibutuhkan oleh role-based restructure berikutnya

---

## 1. Existing APIs yang Menjadi Fondasi

### Auth
- login
- get me
- token-based auth

### Stays
- list
- get detail
- create
- complete
- cancel
- process deposit
- renew
- update stay (`PATCH /stays/:id`)

### Rooms
- CRUD dasar
- occupancy context minimal

### Tenants
- CRUD dasar
- active stay context sebagian
- tenant detail + portal summary melalui response tenant
- `POST /tenants/:id/portal-access`
- `PATCH /tenants/:id/portal-access/status`
- `POST /tenants/:id/portal-access/reset-password`

### Invoices
- list/detail
- create
- update draft
- lines
- issue/cancel

### Invoice Payments
- create/update/delete direct payment existing flow

### Tickets
- list/detail/create existing flow
- assign/progress basics

### Inventory
- inventory items
- movements
- room items existing entities

### Announcements
- CRUD dasar

---

## 2. Existing API Gaps yang Sudah Ditutup
1. `PATCH /stays/:id` → ditutup
2. renew logic existing untuk open-ended stay → ditutup
3. tenant portal access management minimum:
   - create portal user
   - toggle portal status
   - reset password portal
   → dianggap core implemented di tenant context

---

## 3. API yang Perlu Diperkaya, Bukan Dibuat dari Nol

### Tenant detail + portal summary
Response existing sudah cukup untuk:
- `portalUserId`
- `portalEmail`
- `portalIsActive`
- `lastLoginAt`

Yang masih bisa diperkaya nanti:
- `passwordChangedAt`
- summary aksi portal terakhir
- audit trail ringan bila benar-benar dibutuhkan

### Stay detail enriched
Target response tambahan yang diinginkan:
- `openInvoiceCount`
- invoice summary yang konsisten
- meter summary ringan bila diperlukan

### Room detail enriched
Target response:
- active stay summary
- room items embedded
- meter summary ringan

### Inventory item detail enriched
Target response:
- item detail
- low stock flag
- movement history
- room usage summary bila relevan

---

## 4. API vNext yang Masih Menjadi Fokus Berikutnya

### 4.1 Ticket Create from Tenant Context
Target behavior:
- tenant create -> auto-fill tenant/stay/room dari auth/current context
- backoffice create -> dipersempit atau dijujurkan
- ticket flow tenant-first jadi next official phase

### 4.2 Payment Submission + Approval Queue
Target minimum:
- `POST /payment-submissions`
- `GET /payment-submissions/my`
- `GET /payment-submissions/review-queue`
- `POST /payment-submissions/:id/approve`
- `POST /payment-submissions/:id/reject`

### 4.3 Owner Reports
Target endpoints:
- `GET /finance-reports/summary`
- `GET /finance-reports/collections`
- `GET /finance-reports/occupancy`
- `GET /analytics-strategy/owner-dashboard`

---

## 5. Frontend Workaround Policy
Jika API target belum ada:
1. frontend boleh menyiapkan UX target
2. tetapi harus diberi catatan eksplisit "butuh API"
3. jangan pura-pura flow final sudah ada
4. hindari mock behavior yang menyesatkan user operasional

---

## 6. API Prioritas Berdasarkan Roadmap

### Freeze yang sudah cukup tertutup
- Batch 0 backend/frontend blocker utama
- role split inti
- core tenant portal access management

### Prioritas resmi berikutnya
1. ticket tenant-first path
2. module consolidation support
3. payment submission + approval queue
4. owner reports & analytics

---

## 7. Kesimpulan
Gap terbesar proyek saat ini tidak lagi berada di core portal access tenant. Gap resmi berikutnya bergeser ke:
1. ticket tenant-first flow,
2. approval journey finance,
3. dan dashboard owner yang lebih strategis.
