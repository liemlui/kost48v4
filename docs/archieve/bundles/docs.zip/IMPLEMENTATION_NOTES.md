# KOST48 Final Update Notes

## Yang sudah ditingkatkan di frontend
- Semua field relasional yang sebelumnya minta ID manual sekarang dibuat lebih aman dengan dropdown/searchable select untuk:
  - User -> Tenant
  - Stay -> Tenant, Room
  - Meter Reading -> Room
  - Room Item -> Room, Inventory Item
  - Invoice Payment -> Invoice
  - Inventory Movement -> Inventory Item, Room
  - Expense -> Room, Stay
  - Create Invoice -> Stay
- Tabel master data sekarang menampilkan ID beserta nama/konteks relasi jika tersedia.
- Halaman invoice diperbarui agar alurnya lebih sederhana untuk operasional.
- Detail invoice diperbarui dengan quick payment flow, ringkasan tagihan, dan catatan batas kemampuan backend saat ini.
- Halaman master inventory/payment/expense diberi catatan flow bisnis dan catatan backend follow-up.
- Tenant detail sekarang menampilkan portal summary secara read-only.
- Tenant create/edit sekarang memakai wording email yang lebih jujur.
- Tenant context sekarang mendukung create/toggle/reset portal access untuk OWNER/ADMIN dengan feedback yang jelas.

## Yang sudah dipatch di backend source
- Tambah `PATCH /stays/:id` untuk update stay.
- Perbaikan `renewStay` untuk kasus stay tanpa `plannedCheckOutDate`.
- `ProcessDepositDto` memakai enum valid.
- cancel stay sekarang bisa simpan `cancelReason`.
- `findOne` stay sekarang mengembalikan `openInvoiceCount`.
- Ticket number diberi fallback untuk mengurangi race condition duplicate number.
- issue invoice sekarang menolak total <= 0.
- Beberapa service list/detail diperkaya include relasi agar frontend bisa tampilkan nama, bukan angka saja.
- Tenant portal access core endpoint sekarang tersedia:
  - `POST /tenants/:id/portal-access`
  - `PATCH /tenants/:id/portal-access/status`
  - `POST /tenants/:id/portal-access/reset-password`

## Catatan kejujuran verifikasi
- Frontend production build sudah lolos.
- Backend build/type-check sudah lolos pada environment kerja aktual.
- Runtime UAT manual tetap perlu dipertahankan untuk flow penting per role.

## Backend/API yang masih ideal untuk tahap berikutnya
- Endpoint ticket tenant-first yang memanfaatkan auth/current stay context.
- Endpoint payment submission + approval queue.
- Endpoint preview invoice otomatis dari meter reading per periode.
- Endpoint owner dashboard / finance report yang lebih kaya.
