# Current Task — Synced Rewrite

## Active Module
KOST48 V3 — **Freeze Phase B Tenant Identity & Portal Access Simplification + Prepare Phase C Ticket Tenant-Only Redesign**

---

## Active Problem Statement
Codebase sekarang sudah melewati beberapa lapis penting:

### Lapis 1 — Baseline existing tetap dipakai
Flow inti seperti stay, room sync, checkout, deposit terpisah, meter awal atomik, dan invoice/payment existing tetap menjadi fondasi.

### Lapis 2 — Batch 0 frontend sudah cukup tertutup
Blocker frontend paling penting sudah ditutup atau diperkecil secara nyata:
1. renew modal aman terhadap invalid date
2. enum input check-in tidak lagi free-text
3. dashboard invalidation sudah lebih benar
4. meter awal tidak lagi dibaca dari field stay palsu
5. process deposit sudah mendukung opsi penting
6. tenant pages lebih jujur dan lebih berdiri sendiri
7. global 401 handling sudah ada

### Lapis 3 — Role split inti sudah berjalan
Role-based navigation dan dashboard split sudah cukup nyata untuk:
- memisahkan surface Owner/Admin/Staff/Tenant
- mencegah tenant masuk ke dashboard backoffice
- mengurangi rasa “semua role memakai app yang sama”

### Lapis 4 — Phase B core portal access slice sudah cukup tertutup
Phase B tidak lagi sekadar rencana. Core slice yang sudah dianggap selesai/freeze-ready:
1. tenant detail enriched dengan portal summary
2. email portal tidak terasa ganda di create/edit
3. honest visibility untuk status portal
4. toggle portal access dari tenant context
5. create portal account dari tenant context
6. reset password portal dari tenant context

Karena itu fokus aktif sekarang **bukan** lagi kembali ke patch kecil Batch 0 atau membuka portal access besar-besaran, melainkan:
1. freeze hasil Phase B core slice
2. menjaga residual cleanup/UAT kecil
3. lalu masuk ke **Phase C — Ticket Tenant-Only Redesign**

---

## Active Deliverable

### Deliverable A — Freeze Batch 0 Frontend
Yang dianggap sudah cukup tertutup:
- renew modal hardening
- enum-safe check-in
- dashboard invalidation
- meter baseline honesty
- FORFEIT option
- finance paid summary lebih jujur
- tenant announcements lebih defensif
- tenant ticket page lebih tenant-friendly
- global 401 interceptor

### Deliverable B — Freeze Phase A Role-Based Navigation & Dashboard
Yang dianggap sudah cukup berjalan:
- route `/dashboard` aman dari tenant
- dashboard split Owner/Admin/Staff
- tenant default ke portal
- navigasi per role lebih nyata
- owner tidak lagi diposisikan sebagai admin operasional mentah

### Deliverable C — Freeze Phase B Core Portal Access Slice
Yang dianggap cukup tertutup:
- portal summary read-only
- email portal simplification
- portal visibility enhancement / honest UX
- toggle portal access
- create portal account
- reset password portal

### Deliverable D — Buka Phase C
Masuk ke **Ticket Tenant-Only Redesign** sebagai next official phase.

---

## Current Immediate Priority
**Phase C — Ticket Tenant-Only Redesign**

### Tujuan
Membuat ticket benar-benar tenant-first:
- tenant create ticket sederhana
- context tenant/current stay/room auto-filled
- backoffice fokus assign/progress/close
- tenant tidak input ID teknis manual

### Outcome minimum yang dituju
1. tenant bisa membuat tiket dari portal sendiri dengan form yang sederhana
2. backend ticket create memanfaatkan auth context bila realistis
3. backoffice create path dipersempit atau dijujurkan
4. admin/staff fokus tindak lanjut, bukan sumber create utama

---

## Definition of Done untuk Task Aktif Sekarang
Task aktif sekarang dianggap berhasil jika:
1. docs aktif membaca Batch 0 dan Phase A sebagai cukup freeze
2. docs aktif membaca Phase B core portal access sebagai cukup tertutup
3. next focus resmi berpindah ke Ticket Tenant-Only Redesign
4. tidak ada kebingungan antara:
   - stabilisasi lama,
   - role split yang sudah terjadi,
   - phase portal access yang sudah cukup matang,
   - dan phase berikutnya yang memang harus dibuka

---

## Do Not Open in This Task
1. debt flow / hutang
2. scheduler reminder otomatis
3. payment approval vNext penuh
4. owner finance dashboard penuh
5. redesign accounting formal
6. rewrite total backend + frontend sekaligus
7. schema change besar tanpa PLAN eksplisit

---

## Next Safe ACT Order
1. freeze docs Batch 0 + role split + Phase B
2. PLAN ticket tenant-first flow
3. tenant create ticket context-driven
4. backoffice ticket path narrowing / honesty hardening
5. lanjut ke inventory/room consolidation

---

## Closing Status
**Posisi proyek saat ini: Batch 0 frontend sudah cukup tertutup, role-based navigation/dashboard inti sudah berjalan, Phase B core portal access slice sudah cukup freeze-ready, dan fokus resmi berikutnya adalah Ticket Tenant-Only Redesign.**
