# KOST48 V3 — DOCSET INDEX

## Tujuan
Dokumen ini menjadi peta paket dokumen aktif hasil sinkronisasi ulang setelah:
1. konflik antara dokumen lama vs arah produk baru,
2. audit komprehensif backend dan frontend,
3. kebutuhan PLAN besar role-based restructure,
4. kebutuhan batch stabilisasi teknis sebelum ACT besar,
5. penutupan core slice Phase B tenant portal access.

Dokumen ini **mengutamakan konsistensi internal**. Jika ada konflik dengan dokumen lama yang lebih tua, paket ini harus dibaca sebagai **versi sinkronisasi terbaru**.

---

## Paket Dokumen Aktif

### 1. Core control docs
1. `00_SOURCE_OF_TRUTH.md`
2. `01_CURRENT_TASK.md`
3. `02_DECISIONS_LOG.md`
4. `MASTER_PROJECT_NOTE.md`
5. `FRONTEND_PLAN.md`
6. `backend-implementation-contract.md`
7. `project-journal.md`

### 2. Supplementary planning docs
8. `03_ROLE_PERMISSION_MATRIX.md`
9. `04_API_GAP_MATRIX.md`
10. `05_STABILIZATION_BATCH.md`
11. `06_UAT_SCENARIOS.md`
12. `07_IMPLEMENTATION_ROADMAP.md`

---

## Prinsip Pembacaan

### A. Baseline lama tidak dibuang
Flow yang sudah relatif stabil tetap dianggap fondasi:
- single active stay per tenant
- single active stay per room
- room status sinkron dengan stay aktif
- checkout berarti tenant benar-benar keluar
- deposit diproses terpisah
- meter awal tetap atomik
- overpay tetap dilarang

### B. Arah aktif tidak lagi sekadar polish kecil
Arah aktif sekarang dibaca sebagai:
1. **Batch 0 Stabilization** sudah cukup tertutup
2. **Role-based split inti** sudah cukup berjalan
3. **Phase B Tenant Identity & Portal Access core slice** sudah cukup freeze-ready
4. lalu **Phase C Ticket Tenant-Only Redesign** menjadi fokus resmi berikutnya

### C. Semua ACT berikutnya harus kecil
- maksimal 1 flow utama per batch coding
- maksimal 3 file per task Cline kecuali ada alasan eksplisit
- default shell = PowerShell

---

## Urutan Bacaan yang Disarankan
1. `00_SOURCE_OF_TRUTH.md`
2. `01_CURRENT_TASK.md`
3. `MASTER_PROJECT_NOTE.md`
4. `03_ROLE_PERMISSION_MATRIX.md`
5. `04_API_GAP_MATRIX.md`
6. `05_STABILIZATION_BATCH.md`
7. `FRONTEND_PLAN.md`
8. `backend-implementation-contract.md`
9. `02_DECISIONS_LOG.md`
10. `project-journal.md`

---

## Catatan Penutup
Dokumen ini tidak menggantikan schema aktual, bootstrap SQL, atau code aktif. Jika ada konflik:
1. bentuk data ikut `schema.prisma`
2. pagar integritas ikut `bootstrap.sql`
3. alur bisnis existing ikut contract baseline
4. arah redesign ikut dokumen sinkronisasi ini
