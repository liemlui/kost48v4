# FRONTEND_PLAN — KOST48 V3 (Synced Rewrite)

## Status Dokumen
- **Versi:** 5.2
- **Status:** Active synced plan
- **Cakupan:** Backoffice + Tenant Portal + Role-based IA
- **Catatan:** Batch 0 frontend dianggap cukup tertutup, role split inti dianggap cukup berjalan, dan core slice Phase B portal access sudah cukup freeze-ready.

---

## 1. Tujuan
Dokumen ini memecah arah frontend menjadi beberapa lapis:

### Lapis 1 — Stabilization
Menutup crash, stale data, dan mismatch contract.

### Lapis 2 — Role-Based Restructure
Mendesain ulang surface frontend agar:
- lebih padat,
- lebih relevan per role,
- lebih human-readable,
- lebih dekat dengan alur operasional nyata.

---

## 2. Prinsip Besar UI/UX

1. **Role first**
   Owner, Admin, Staff, Tenant tidak boleh melihat surface yang sama.

2. **Compact over clutter**
   Jangan jadikan semua tabel sebagai menu utama.

3. **Human-readable relations**
   Tampilkan nama, kode, konteks — bukan ID mentah.

4. **One flow, one place**
   Jika flow sudah wizard/contextual, jangan diduplikasi sebagai hard menu tanpa alasan.

5. **Defensive UI**
   Invalid/null data tidak boleh menjatuhkan halaman.

6. **Honest UX**
   Jangan memberi makna berlebihan pada status yang secara data belum pasti.

7. **Approval feels like one journey**
   Tagihan, bukti bayar, verifikasi, dan status harus terasa satu alur.

---

## 3. Batch 0 — Frontend Stabilization

### 3.1 Tujuan
Menutup bug yang membuat UX existing menyesatkan atau rusak.

### 3.2 Status Eksekusi
#### Yang dianggap cukup tertutup
- renew modal runtime hardening
- check-in enum inputs
- meter invalidation
- dashboard invalidation
- meter awal check-in card
- process deposit modal (`FORFEIT`)
- tenant tickets page
- tenant announcements lebih defensif
- global 401 handling
- login hygiene dan dashboard route safety

### 3.3 Status Batch 0
**Batch 0 frontend-side dianggap cukup selesai untuk melangkah ke phase berikutnya.**

---

## 4. Role-Based Information Architecture

### 4.1 Owner
#### Menu target
- Dashboard Owner
- Laporan Keuangan & Analitik
- Users
- Announcements

#### Fokus halaman
- KPI utama
- billed/collected/overdue
- occupancy
- ringkasan expense
- ratio bisnis
- strategic insight

### 4.2 Admin
#### Menu target
- Dashboard Admin
- Stays
- Rooms
- Tenants
- Invoices & Approval Pembayaran
- Tickets
- Announcements
- Users

#### Fokus halaman
- operasi harian
- approval queue
- tindak lanjut stay / room / tenant
- backoffice control

### 4.3 Staff
#### Menu target
- Dashboard Staff
- Tickets
- Inventory
- Rooms (context terbatas)

#### Fokus halaman
- pekerjaan teknis
- ticket yang ditugaskan
- stock/low stock
- update progress

### 4.4 Tenant
#### Menu target
- Hunian Saya
- Tagihan Saya
- Tiket Saya
- Pengumuman

#### Fokus halaman
- sederhana
- context-driven
- tidak perlu input ID teknis manual

---

## 5. Modul yang Harus Diperkecil / Di-Embed

### 5.1 Meter Readings
- tidak lagi dianggap menu utama
- akses dari stay detail, room detail, atau context billing

### 5.2 Room Items
- dikelola dari room detail
- bukan menu terpisah utama

### 5.3 Inventory Movements
- dikelola dari inventory item detail
- bukan menu utama

### 5.4 Ticket Create
- tidak ada create ticket di backoffice pada target akhir
- create hanya dari tenant portal

---

## 6. Fase Re-Architecture

## Fase A — Role-based Navigation & Dashboard Split
### Tujuan
Memecah surface per role secara nyata.

### Status
**Sudah berjalan dan cukup tertutup di level inti.**

### Yang sudah terjadi
- route dashboard aman dari tenant
- dashboard split Owner/Admin/Staff sudah nyata
- menu per role lebih jelas
- tenant portal tetap sederhana

---

## Fase B — Tenant Identity & Portal Access Simplification
### Tujuan
Menyatukan tenant data dan portal access experience.

### Scope inti yang sudah berjalan
- tenant detail memuat portal summary
- email portal tidak terasa ganda
- status portal lebih jelas
- create portal account dari tenant context
- toggle portal access dari tenant context
- reset password portal dari tenant context

### Definition of Done
- operator tidak bingung soal email tenant vs email portal
- create/edit tenant terasa satu flow
- portal access lebih jelas artinya
- lifecycle dasar portal tenant bisa dikelola dari tenant context

### Status
**Core slice dianggap cukup freeze-ready.**

---

## Fase C — Ticket Flow Redesign
### Tujuan
Membuat flow ticket sesuai realitas tenant-first.

### Scope
- tenant create ticket sederhana
- auto-fill context tenant/current stay/room
- backoffice fokus assign/progress/close

### Definition of Done
- tenant tidak input tenantId/roomId/stayId manual
- admin/staff fokus tindak lanjut, bukan create

### Status
**Next official frontend focus.**

---

## Fase D — Inventory & Rooms Consolidation
### Tujuan
Menjadikan room dan inventory lebih natural.

### Scope
- room items embedded
- inventory movements embedded
- staff melihat context lebih utuh di item/room detail

### Definition of Done
- user tidak perlu lompat menu untuk memahami satu item atau satu room

---

## Fase E — Invoice + Payment Approval Experience
### Tujuan
Menyederhanakan invoice dan pembayaran ke alur approval.

### Scope target
- invoice list sederhana
- invoice detail jelas
- tenant submit bukti bayar
- approval queue admin
- status verifikasi terlihat oleh tenant

### Catatan penting
Fase ini **butuh API vNext** dan tidak boleh dianggap selesai dari baseline existing saja.

---

## Fase F — Owner Finance & Strategy Dashboard
### Tujuan
Membuat surface owner benar-benar strategis.

### Scope target
- KPI properti
- billed / collected / overdue
- occupancy & active tenant
- expense summary
- ratio bisnis utama
- laporan keuangan ringkas
- strategic cards / business tool widgets

---

## 7. Prioritas Eksekusi yang Disarankan
1. **Freeze Batch 0 frontend**
2. **Freeze Fase A — Role-based Navigation & Dashboard Split**
3. **Freeze Fase B — Tenant Identity & Portal Access core slice**
4. **Fase C — Ticket Flow Redesign**
5. **Fase D — Inventory & Rooms Consolidation**
6. **Fase E — Invoice + Payment Approval Experience**
7. **Fase F — Owner Finance & Strategy Dashboard**

---

## 8. Ringkasan Akhir
**Frontend KOST48 tidak lagi diposisikan sebagai sekadar backoffice tabel. Fondasi existing sudah cukup distabilkan, role split inti sudah berjalan, core portal access slice sudah cukup matang, dan langkah resmi berikutnya adalah ticket tenant-first flow sebelum bergerak ke approval flow finance dan dashboard owner yang lebih besar.**
