# Backend Implementation Contract — KOST48 V3 (Synced Rewrite)

## 1. Tujuan Dokumen
Dokumen ini mendefinisikan dua lapis kontrak:

### A. Baseline Existing Contract
Kontrak yang sudah relatif melekat ke codebase sekarang dan harus dihormati agar tidak merusak data integrity yang sudah ada.

### B. Target vNext Contract
Kontrak target untuk role-based restructure dan approval flow berikutnya.

Dokumen ini membantu membedakan:
- apa yang **sudah** menjadi rule existing,
- apa yang **belum** ada dan masih target vNext.

---

## 2. Arsitektur yang Dikunci
- 1 backend modular NestJS
- 1 database PostgreSQL
- 1 Prisma schema
- 2 app utama: Backoffice + Tenant Portal
- tidak ada microservices

---

## 3. Prinsip Umum
1. `schema.prisma` = bentuk data
2. `bootstrap.sql` = pagar integritas
3. service = alur bisnis
4. controller tipis
5. actor diambil dari auth context
6. semua transaksi penting multi-entity wajib atomik

---

## 4. Baseline Existing Contract

### 4.1 Stay
#### Single active stay
- 1 tenant hanya boleh 1 stay aktif
- 1 room hanya boleh 1 stay aktif

#### Create stay
- `pricingTerm` wajib
- rent/deposit/tariff boleh default dari room
- meter awal listrik dan air wajib
- meter awal disimpan sebagai dua `MeterReading`
- room harus sync ke `OCCUPIED`

#### Checkout
- `ACTIVE -> COMPLETED`
- checkout = tenant benar-benar keluar
- `checkoutReason` wajib saat complete
- room bisa kembali `AVAILABLE`

#### Cancel
- `ACTIVE -> CANCELLED`
- cancel tidak boleh mematahkan guard existing lain

#### Renew stay
- renewal = extend existing active stay
- bukan create parallel stay baru
- invoice renewal boleh dibuat otomatis dalam baseline existing sekarang
- validasi overlap renewal belum kaya

### 4.2 Deposit
- deposit lifecycle tetap di `Stay`
- deposit diproses terpisah
- process deposit hanya boleh jika stay `COMPLETED`/`CANCELLED`
- process deposit diblok jika masih ada invoice `ISSUED`/`PARTIAL`

### 4.3 Meter reading
- dipakai untuk listrik dan air
- `[roomId, utilityType, readingAt]` unik
- nilai tidak boleh turun
- meter awal create stay adalah baseline pertama

### 4.4 Invoice
- invoice header = tagihan
- line = rincian biaya
- total invoice dikelola otomatis dari line
- service tidak boleh set total manual
- line hanya boleh berubah saat invoice `DRAFT`

### 4.5 Payment existing
- admin dapat input `InvoicePayment` langsung
- overpay tidak boleh
- update status invoice:
  - 0 paid -> `ISSUED`
  - partial -> `PARTIAL`
  - full -> `PAID`

### 4.6 Announcement existing
- announcement sederhana
- published / audience / active window tetap cukup

### 4.7 Ticket existing
- ticket dasar sudah ada
- tenant bisa lihat progress
- backoffice bisa update status
- existing flow masih belum tenant-first sepenuhnya

### 4.8 Inventory existing
- stock global di `InventoryItem.qtyOnHand`
- movement sync stok
- room item masih entity penting tapi surface frontend lama terlalu terpisah

### 4.9 Tenant Portal Access Existing
Core portal access management minimum sekarang dianggap sudah ada di baseline existing:
- tenant detail + portal summary
- create portal user dari tenant context
- activate/deactivate portal access dari tenant context
- reset password portal tenant dari tenant context

Rule existing:
- relasi `Tenant ↔ User TENANT` tetap one-to-one optional
- create/toggle/reset portal access hanya untuk OWNER/ADMIN
- toggle/reset hanya berlaku untuk portal user tenant existing
- reset password tenant portal bersifat operator-initiated dari tenant context, bukan forgot-password global
- error message tetap Bahasa Indonesia dan operasional-friendly

---

## 5. Stabilization Rules (Wajib Ditutup Sebelum vNext Besar)

### 5.1 Backend blocker existing
1. `PATCH /stays/:id` harus tersedia
2. `renewStay` open-ended period bug harus ditutup
3. `ProcessDepositDto.action` harus enum-safe
4. ticket number race condition harus minimal diberi fallback aman
5. `cancelReason` idealnya disimpan eksplisit
6. `findOne` stay idealnya konsisten dengan `openInvoiceCount`

### 5.2 Prinsip patch stabilisasi
- tetap kecil
- jangan ubah schema besar tanpa alasan
- hormati trigger dan guard existing
- jangan paksa redesign vNext ke batch ini

---

## 6. Target vNext Contract

### 6.1 Product surface per role
#### Owner
- dashboard strategis
- finance reports
- KPI
- ratios
- business insights

#### Admin
- stays
- rooms
- tenants
- approvals
- announcements
- users
- ticket monitoring

#### Staff
- ticket lapangan
- inventory
- pekerjaan teknis

#### Tenant
- hunian saya
- tagihan saya
- tiket saya
- pengumuman

### 6.2 Tenant Portal Access Management (Remaining / Optional Next-Level)
Core minimum sudah implemented di baseline existing.
Yang **belum perlu diasumsikan** sebagai complete suite:
- dedicated invite flow/email delivery
- random password generator
- forced password change on first login
- richer audit/reporting untuk aksi portal access
- self-service forgot-password final dari sisi tenant

### 6.3 Ticket vNext
Target:
- create ticket utama hanya dari tenant portal
- `tenantId`, `roomId`, `stayId` diisi otomatis dari context auth/current stay
- backoffice fokus assign/progress/close

Catatan:
- selama existing flow masih hidup, transisi perlu dijaga agar tidak memutus operasional

### 6.4 Payment Approval vNext
#### Konsep
Pisahkan:
1. **PaymentSubmission** oleh tenant
2. **InvoicePayment final** setelah approval admin

#### Target entity / flow minimum
- `invoiceId`
- `submittedByTenantId`
- `amountSubmittedRupiah`
- `paymentMethod`
- `referenceNo`
- `note`
- `proof metadata`
- `status` = `PENDING_REVIEW | APPROVED | REJECTED`
- reviewer summary

#### Flow target
1. tenant melihat invoice
2. tenant submit bukti bayar
3. admin review
4. jika approve -> create `InvoicePayment` final
5. jika reject -> tenant melihat status reject

#### Constraint
- overpay final tetap dilarang
- approval harus idempotent/race-safe
- attachment harus aman

### 6.5 Renewal vs Payment Approval
Target keputusan vNext harus eksplisit:
- apakah renewal final saat invoice renewal dibuat
- atau final setelah payment approval

Sampai freeze baru ada:
- pakai baseline existing dulu
- jangan buat half-state implisit

### 6.6 Announcement Audience vNext
Audience target:
- `TENANT`
- `STAFF`
- `ADMIN`
- `STAFF_ADMIN`
- `ALL`

### 6.7 Inventory & Room Surface vNext
- meter readings bukan menu utama frontend
- room items di room detail
- inventory movements di inventory item detail
- backend perlu mendukung detail kaya context

### 6.8 Owner Reports vNext
Target endpoint read-heavy:
- occupancy summary
- billed / collected / overdue
- expense summary
- active tenants/rooms/stays
- basic ratios
- management reports

Catatan:
Jika accounting formal belum ada, label report harus jelas sebagai management report, bukan laporan akuntansi final.

---

## 7. Transaction Boundary
Gunakan `prisma.$transaction()` untuk:
- create stay + room update + meter + invoice
- complete stay + room release + deposit guard logic
- create/update/delete invoice line + recalc
- create payment + invoice status sync
- approval payment submission + create final invoice payment
- inventory movement + stock sync + room item sync
- create portal account dari tenant context bila perlu menjaga atomicity

---

## 8. DTO Validation Policy
- angka rupiah: `@IsInt()` + `@Min(...)`
- decimal input: `@IsNumberString()` bila dikirim string
- enum: `@IsEnum(...)`
- optional: `@IsOptional()`
- action string yang sebenarnya enum tidak boleh hanya `@IsString()`
- password manual operator harus divalidasi eksplisit sesuai scope endpoint terkait

---

## 9. Error Message Policy
Gunakan Bahasa Indonesia yang konsisten dan operasional-friendly.

Contoh:
- `Kamar sudah ditempati stay aktif lain`
- `Tenant masih memiliki stay aktif`
- `Pembayaran melebihi total invoice`
- `Stay tidak ditemukan`
- `Stay tidak aktif, tidak dapat diperpanjang`
- `Deposit tidak dapat diproses karena masih ada tagihan terbuka`
- `Tenant ini belum memiliki akun portal`
- `Password portal tenant berhasil diperbarui`

---

## 10. Hal yang Tidak Boleh Diasumsikan Sudah Ada
1. payment submission upload flow
2. approval queue admin yang final
3. ticket tenant-first create final
4. owner analytics matang
5. role-based dashboard lengkap
6. embedded room/item/movement surface final
7. self-service forgot-password tenant final

Semua itu adalah target vNext atau pengayaan lanjutan, bukan existing baseline otomatis.

---

## 11. Rule Penutup
Jika ada rule baru, tanyakan:
1. apakah ini bentuk data? -> schema
2. apakah ini harus aman walau backend bug? -> bootstrap SQL
3. apakah ini alur bisnis / workflow / validasi / kalkulasi? -> service contract
4. apakah ini target vNext, bukan existing? -> tandai eksplisit sebagai **target**, jangan dianggap live
