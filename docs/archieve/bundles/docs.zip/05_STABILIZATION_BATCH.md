# Batch 0 — Stabilization

## Tujuan
Menutup blocker dan gap nyata pada baseline existing sebelum role-based restructure besar berjalan.

---

## 1. Scope Batch

### 1.1 P0 — Kritis
1. `RenewStayModal` invalid date crash
2. `PATCH /stays/:id` missing endpoint
3. `renewStay` open-ended period bug
4. meter invalidation mismatch
5. free-text enum inputs di check-in wizard

### 1.2 P1 — Menengah
6. dashboard invalidation setelah aksi stay
7. meter awal card dari reading baseline, bukan field stay palsu
8. FORFEIT option di deposit modal
9. paid summary finance
10. tenant announcements path
11. global 401 interceptor
12. MyTicketsPage tenant-friendly

---

## 2. Status Aktual Batch

### 2.1 Backend blocker existing
- `PATCH /stays/:id` → **ditutup di backend source**
- `renewStay` open-ended bug → **ditutup di backend source**

### 2.2 Frontend stabilization
Yang dianggap cukup tertutup:
1. `RenewStayModal` aman terhadap invalid/null date
2. `CheckInWizard` enum-safe
3. dashboard invalidation sudah diperbaiki
4. meter awal tidak lagi dibaca dari field stay palsu
5. process deposit mendukung `FORFEIT`
6. `FinanceTab` lebih jujur terhadap paid summary
7. tenant announcements lebih defensif
8. global 401 interceptor aktif
9. `MyTicketsPage` lebih tenant-friendly
10. tenant route/dashboard tidak lagi bocor ke surface admin
11. login tidak lagi memprefill kredensial sensitif

### 2.3 Residual kecil
- housekeeping config/resource agar makin selaras dengan compact IA
- verifikasi runtime ringan per role setelah perubahan menu/config terakhir

---

## 3. Acceptance Criteria Batch 0
Batch 0 dianggap cukup selesai jika:
1. tidak ada crash renew modal
2. save notes stay tidak lagi terputus oleh gap kontrak utama
3. renewal open-ended tidak menghasilkan period yang salah
4. meter tab refresh benar
5. check-in wizard enum-safe
6. issue UI menyesatkan utama berkurang nyata
7. tenant surface tidak lagi terasa sekadar copy backoffice
8. tenant tidak bisa jatuh ke dashboard backoffice
9. auth expired tidak berhenti di error generik

### Status
**Batch 0 frontend-side dianggap cukup tertutup dan sudah tidak lagi menjadi fokus aktif utama.**

---

## 4. Out of Scope Batch 0
- payment approval vNext penuh
- owner finance dashboard
- role-based dashboard split penuh yang lebih kaya analytics
- schema redesign besar
- debt flow
- scheduler otomatis

---

## 5. Catatan Transisi
Batch 0 sudah cukup tertutup.
Fokus resmi bergerak berurutan ke:
1. freeze hasil Batch 0,
2. freeze role-based navigation/dashboard inti,
3. freeze Phase B core portal access,
4. lalu masuk ke **Phase C — Ticket Tenant-Only Redesign**.

---

## 6. Catatan Penutup
Batch ini berhasil menjalankan fungsi utamanya: membersihkan fondasi existing agar cukup aman dipakai masuk ke role-based restructure berikutnya.
