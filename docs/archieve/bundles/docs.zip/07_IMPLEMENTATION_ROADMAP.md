# Implementation Roadmap — Synced Rewrite

## Tujuan
Roadmap ini memecah proyek menjadi tahap yang realistis, bukan rewrite total satu langkah.

---

## Phase 0 — Doc Sync
### Status
Selesai pada paket sinkronisasi ini.

### Hasil
- konflik arah docs dikonsolidasikan
- baseline existing dipisahkan dari target vNext
- batch stabilisasi didefinisikan
- role-based restructure difreeze sebagai arah resmi berikutnya

---

## Phase 1 — Batch 0 Stabilization
### Goal
Menutup blocker dan gap existing.

### Milestones
1. renew modal safe
2. patch stay endpoint ada
3. renew logic benar
4. meter refresh benar
5. enum-safe check-in
6. dashboard invalidation
7. 401 interceptor
8. tenant pages lebih jujur

### Status
**Cukup tertutup untuk frontend-side, dan tidak lagi menjadi fokus aktif utama.**

### Exit criteria
Fondasi existing cukup bersih untuk dipakai melangkah ke role split.

---

## Phase 2 — Role-Based Navigation & Dashboard
### Goal
Memisahkan Owner/Admin/Staff/Tenant surface secara nyata.

### Milestones
1. menu split
2. dashboard split
3. CTA ganda dihilangkan
4. route guard/surface role-aware

### Status
**Sudah berjalan dan cukup tertutup di level inti.**

### Exit criteria
User tidak lagi merasa semua role memakai produk yang sama.

---

## Phase 3 — Tenant Identity & Portal Access
### Goal
Menyatukan tenant data dan portal access experience.

### Milestones
1. tenant detail enriched
2. portal summary tampil
3. email portal tidak terasa ganda
4. honest portal visibility
5. create portal account dari tenant context
6. toggle portal access dari tenant context
7. reset password portal dari tenant context

### Status
**Core slice dianggap freeze-ready dan cukup tertutup.**

### Exit criteria
Operator paham siapa tenant, siapa user portal, dan hubungannya tanpa kebingungan, serta dapat mengelola lifecycle dasar portal tenant dari tenant context.

---

## Phase 4 — Ticket Tenant-Only Redesign
### Goal
Menjadikan tenant sumber utama ticket.

### Milestones
1. tenant create ticket sederhana
2. backoffice create path dipersempit
3. tenant/stay/room context auto-filled
4. admin/staff fokus progress dan close

### Status
**Next official phase.**

### Exit criteria
Ticket flow terasa natural bagi tenant dan backoffice.

---

## Phase 5 — Inventory & Room Consolidation
### Goal
Menyederhanakan surface inventory/room.

### Milestones
1. room items embedded
2. movement embedded
3. detail room/item lebih kaya context

### Exit criteria
User tidak perlu lompat ke banyak menu kecil untuk satu kasus operasional.

---

## Phase 6 — Invoice + Payment Approval vNext
### Goal
Memindahkan finance UX dari flow teknis existing ke approval journey.

### Milestones
1. design API submission
2. proof upload flow
3. approval queue
4. tenant status feedback
5. invoice/payment sync

### Exit criteria
Tagihan, pembayaran, dan verifikasi terasa satu alur.

---

## Phase 7 — Owner Finance & Strategy Dashboard
### Goal
Membuat owner dashboard bernilai strategis.

### Milestones
1. KPI utama
2. collections summary
3. occupancy summary
4. expense summary
5. ratio bisnis
6. management report widgets

### Exit criteria
Owner bisa ambil keputusan tanpa masuk ke tabel mentah operasional.

---

## Prinsip Roadmap
1. Jangan lompat phase
2. Batch 0 harus cukup stabil dulu
3. Phase besar tetap dipecah jadi ACT kecil
4. Build success tidak sama dengan done
5. Runtime verification wajib di phase penting
