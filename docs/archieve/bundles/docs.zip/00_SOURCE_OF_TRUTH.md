# Source of Truth — KOST48 V3 (Synced Rewrite)

## Stack
- **Backend:** NestJS + Prisma + PostgreSQL
- **Frontend:** React + Vite + TypeScript + React-Bootstrap + TanStack Query
- **Auth:** JWT Bearer Token
- **Environment kerja default:** Windows + VS Code + PowerShell

---

## Prioritas Source of Truth

### Level 1 — Data integrity
1. `backend/prisma/schema.prisma`
2. `backend/sql/bootstrap.sql`

### Level 2 — Contract & arah implementasi
3. `backend-implementation-contract.md`
4. `MASTER_PROJECT_NOTE.md`
5. `01_CURRENT_TASK.md`
6. `FRONTEND_PLAN.md`

### Level 3 — Freeze & histori keputusan
7. `02_DECISIONS_LOG.md`
8. `project-journal.md`

### Level 4 — Docs pendukung
9. `03_ROLE_PERMISSION_MATRIX.md`
10. `04_API_GAP_MATRIX.md`
11. `05_STABILIZATION_BATCH.md`
12. `06_UAT_SCENARIOS.md`
13. `07_IMPLEMENTATION_ROADMAP.md`

---

## Effective Current Direction

### Ringkasan singkat
Arah aktif proyek sekarang dibaca berlapis:

1. **Baseline existing tetap dihormati**
2. **Batch 0 frontend dianggap cukup tertutup**
3. **Role-based navigation/dashboard split inti dianggap cukup berjalan**
4. **Phase B — Tenant Identity & Portal Access Simplification core slice dianggap freeze-ready**
5. **Next official phase = Phase C / Ticket Tenant-Only Redesign**

Jadi fokus aktif **bukan** lagi kembali ke patch kecil Batch 0, dan **juga bukan** rewrite total tanpa kontrol.

---

## Baseline Existing yang Tetap Dihormati

### Stay & Room
1. Satu tenant hanya boleh punya satu stay aktif.
2. Satu room hanya boleh punya satu stay aktif.
3. `Room.status` harus sinkron dengan stay aktif.
4. Backoffice create stay tetap menghasilkan stay aktif, bukan flow approval panjang.
5. Checkout berarti tenant benar-benar keluar kos.

### Deposit
6. Deposit diproses terpisah setelah checkout.
7. Process deposit tetap diblok jika invoice stay masih `ISSUED` atau `PARTIAL`.
8. Bukti deposit sudah/belum dibayar di UI tidak boleh hanya dibaca dari `depositStatus`.

### Meter
9. Meter awal saat check-in bukan field di `Stay`.
10. Meter awal wajib dicatat sebagai `MeterReading` atomik di transaksi create stay.
11. Constraint `[roomId, utilityType, readingAt]` tetap unik.
12. Monotonic meter tetap wajib dijaga.

### Invoice & Payment
13. Overpay tetap tidak boleh melebihi total invoice final.
14. `Invoice.totalAmountRupiah` harus mengikuti recalc dari `InvoiceLine`.
15. Service tidak boleh set `Invoice.totalAmountRupiah` manual.
16. Invoice line hanya boleh berubah saat invoice `DRAFT`.

### Scope control
17. Debt flow tidak dibangun sekarang.
18. Scheduler reminder otomatis tidak dibangun sekarang.
19. Redesign state model besar stay tidak dibuka tanpa PLAN eksplisit.

---

## Fakta Implementasi Existing yang Perlu Diingat

### Yang sudah ada di codebase
- create stay
- checkout / cancel / process deposit
- initial meter atomik
- renew stay endpoint
- invoice automation awal dan renewal dalam baseline existing
- pembayaran invoice langsung oleh admin
- reminder ringan frontend-only
- deposit queue ringan
- portal tenant dasar
- **portal summary tenant-context**
- **create portal account dari tenant context**
- **toggle portal access tenant-context**
- **reset password portal tenant-context**
- ticket dasar

### Yang belum boleh diasumsikan final
- renew flow runtime sepenuhnya aman
- helper date renew modal aman untuk semua input
- semua paid summary di finance UI akurat
- semua query invalidation lintas halaman sudah benar
- ticket tenant-first final
- payment submission + approval queue final
- owner analytics matang

---

## Fokus Resmi Saat Ini

### Status freeze yang sudah cukup tertutup
- Batch 0 frontend stabilization
- Phase A role-based navigation/dashboard split inti
- Phase B core portal access slice:
  1. tenant detail + portal summary
  2. email portal simplification
  3. honest portal visibility
  4. toggle portal access
  5. create portal account
  6. reset password portal

### Immediate active focus berikutnya
**Phase C — Ticket Tenant-Only Redesign**
- tenant create ticket sederhana
- context tenant/stay/room auto-filled
- backoffice fokus assign/progress/close

---

## Prinsip Pengambilan Keputusan Selanjutnya

Jika ada konflik antara:
- docs lama,
- audit teknis,
- atau arah produk baru,

maka pakai aturan ini:

1. **Schema & bootstrap tetap menang untuk kebenaran data**
2. **Bug runtime nyata menang atas asumsi docs lama**
3. **Batch 0 Stabilization menang atas polishing kosmetik**
4. **Role-based restructure menang atas mempertahankan IA lama**
5. **ACT kecil bertahap menang atas rewrite besar tanpa kontrol**

---

## Dokumen Aktif
- `DOCSET_INDEX.md`
- `00_SOURCE_OF_TRUTH.md`
- `01_CURRENT_TASK.md`
- `02_DECISIONS_LOG.md`
- `MASTER_PROJECT_NOTE.md`
- `FRONTEND_PLAN.md`
- `backend-implementation-contract.md`
- `project-journal.md`
- `03_ROLE_PERMISSION_MATRIX.md`
- `04_API_GAP_MATRIX.md`
- `05_STABILIZATION_BATCH.md`
- `06_UAT_SCENARIOS.md`
- `07_IMPLEMENTATION_ROADMAP.md`
