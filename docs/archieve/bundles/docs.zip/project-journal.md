# Project Journal — KOST48 V3 (Synced Rewrite)

## Tujuan
Jurnal ini merangkum milestone, perubahan fokus, hasil audit, dan keputusan sesi secara kronologis.
Tujuan utamanya bukan mencatat semua detail teknis kecil, tetapi menjaga jejak logika proyek.

---

## 2026-04-13 — Audit Happy Path Core Commercial Flow
- backend core commercial flow diverifikasi hingga checkout dan process deposit
- bug double processing deposit sempat ditemukan dan ditutup
- kesimpulan awal: fondasi inti backend cukup kuat untuk dijadikan dasar integrasi frontend

---

## 2026-04-14 — Frontend Cleanup Awal
- tenants form dirapikan agar lebih sinkron dengan backend
- dashboard 500 error ditutup lewat safe serialization
- navigasi stays disederhanakan menjadi satu entry dengan toggle status

---

## 2026-04-15 — Regression Cleanup Batch 1
### Fokus
- check-in success handling
- query invalidation
- type safety response create stay
- format tanggal, period, due, Rupiah
- occupancy consistency tenant

### Hasil penting
- false error saat create stay hilang
- list lebih aman terhadap invalid date dan object rendering
- occupancy tenant berbasis active stay menjadi lebih akurat

---

## 2026-04-15 — Freeze Logic Stays & Scope Aktif Lama
### Yang dibekukan
- checkout = tenant keluar kos
- deposit diproses terpisah
- debt flow ditunda
- reminder H-10 / H-7 / H-3 / H+1 tetap plan-only
- meter awal sebagai `MeterReading`, bukan field `Stay`
- `PENDING` tidak dibuka di scope aktif

### Makna fase ini
- project saat itu masih dibaca sebagai polish + hardening vertical slice kecil

---

## 2026-04-15 — Tenants & Rooms Final Hardening
### Tenants
- occupancy warning
- guard nonaktif tenant occupied
- label Indonesia
- payload tenant dibersihkan

### Rooms
- room list diperkaya tenant aktif
- room occupied tidak bisa dinonaktifkan
- tampilan status dan penghuni dirapikan

---

## 2026-04-16 — Audit Stays UX
- check-in column diperbaiki
- finance tab dirapikan
- wizard guard ditinjau
- blocker backend initial meter teridentifikasi saat itu

---

## 2026-04-16 — Fase 3A Backend: Atomic Initial Meter
- create stay ditambah meter awal wajib
- transaction create stay sekarang membuat 2 baseline meter
- validasi non-negatif / duplicate / monotonic ditutup
- backend build sukses

---

## 2026-04-16 — Fase 3A Frontend: Meter Awal Wajib
- wizard check-in diselaraskan dengan DTO backend baru
- field meter awal jadi required
- validasi frontend bekerja
- payload submit selaras dengan backend

---

## 2026-04-16 — End-to-End Verification
- frontend menolak meter kosong/negatif/non-numeric
- submit valid sukses
- backend menyimpan 2 baseline meter
- blocker lama initial meter dianggap tertutup

---

## 2026-04-16 — Checkout UX Hardening
- tombol utama menjadi Checkout
- modal konfirmasi checkout
- `checkoutReason` wajib
- hint deposit terpisah

---

## 2026-04-17 — Reminder Lifecycle Ringan
### ACT 1
- reminder harian di dashboard

### ACT 2
- reminder badge di stays list

### ACT 3
- due-soon badge di invoices list

### Kesimpulan
- reminder ringan frontend-only selesai
- scheduler dan automation tetap tidak dibuka

---

## 2026-04-17 — Deposit Queue Read-Only
- backend list stay diperkaya filter `depositStatus` dan `openInvoiceCount`
- dashboard menampilkan antrian deposit kecil
- tetap read-only
- tidak membuka redesign besar

---

## 2026-04-17 — Wizard Eligibility Hardening
- dropdown tenant dan guard ACTIVE-only disesuaikan
- wizard akhirnya dianggap cukup stabil untuk ditutup

---

## 2026-04-17 — Commercial Entry Flow
- sempat dibuka sebagai plan berikutnya
- menghasilkan ACT kecil di area list consistency, payment UX, dan warning wording
- tetap belum menjadi redesign finance besar

---

## 2026-04-18 — Invoice Automation & Renew Flow
- create stay membuat invoice awal `DRAFT`
- renew stay membuat invoice renewal `DRAFT`
- tombol perpanjang stay dan renew modal ada di frontend
- code audit menunjukkan flow ada
- runtime verification masih bercampur: sebagian lolos, sebagian masih perlu kehati-hatian

---

## 2026-04-18 — Audit Komprehensif Backend & Frontend
### Audit backend menyimpulkan:
- fondasi DB sangat kuat
- happy path inti ada
- ada gap kritis:
  1. `PATCH /stays/:id` belum ada
  2. `renewStay` period bug untuk stay tanpa `plannedCheckOutDate`

### Audit frontend menyimpulkan:
- fondasi API layer dan auth cukup solid
- ada bug kritis:
  1. meter tab tidak refresh karena query key mismatch
  2. enum input check-in masih free-text
  3. save notes stay 404 karena backend gap
- ada beberapa gap medium:
  - paid summary
  - meter awal di UI
  - FORFEIT
  - dashboard invalidation
  - tenant ticket page
  - announcements tenant
  - 401 interceptor

### Dampak audit
- jelas bahwa proyek butuh stabilization batch
- role-based restructure tidak boleh mulai dari fondasi yang masih retak

---

## 2026-04-18 — Sinkronisasi Ulang Dokumen Aktif
### Kesimpulan besar
- docs lama sempat bertabrakan
- sebagian masih membaca fokus sebagai verify/freeze invoice automation kecil
- sebagian lain mulai mengarah ke restructure besar

### Keputusan sinkronisasi
- baseline existing tetap dipakai
- fokus aktif resmi menjadi:
  1. **Batch 0 Stabilization**
  2. lalu **PLAN besar role-based restructure**

### Makna
- proyek tidak dibaca lagi sebagai sekadar polish kecil
- tetapi juga tidak dibaca sebagai rewrite total satu langkah
- langkah yang benar adalah stabilisasi dulu, lalu redesign bertahap

---

## 2026-04-19 — Paket Dokumen Sinkronisasi Dibuat
Paket docs yang disiapkan dalam batch ini:
- `DOCSET_INDEX.md`
- `00_SOURCE_OF_TRUTH.md`
- `01_CURRENT_TASK.md`
- `02_DECISIONS_LOG.md`
- `MASTER_PROJECT_NOTE.md`
- `FRONTEND_PLAN.md`
- `backend-implementation-contract.md`
- `03_ROLE_PERMISSION_MATRIX.md`
- `04_API_GAP_MATRIX.md`
- `05_STABILIZATION_BATCH.md`
- `06_UAT_SCENARIOS.md`
- `07_IMPLEMENTATION_ROADMAP.md`

### Tujuan paket baru
- menyatukan semua arah lama dan baru
- menurunkan konflik antar dokumen
- memberi peta ACT yang lebih jujur dan lebih aman

---

## Status Terkini
**Fondasi lama tetap berharga, tetapi proyek sekarang resmi dibaca sebagai stabilization batch lalu role-based restructure bertahap — bukan verify kecil terus-menerus, dan bukan rewrite total tanpa kontrol.**

## 2026-04-19 — Batch A Frontend Freeze
- route `/dashboard` dikunci agar tenant tidak bisa masuk ke dashboard backoffice
- login tidak lagi memprefill kredensial
- dashboard invalidation setelah check-in diperbaiki agar mengikuti key dashboard yang nyata
- hasilnya: hardening role guard + auth hygiene dianggap cukup stabil untuk ditutup

## 2026-04-19 — Batch B Frontend Freeze
- tenant pages dibuat lebih jujur dalam membedakan empty state vs error operasional
- overdue invoice tenant dihitung per tanggal, bukan per jam-menit-detik
- announcements tenant dibuat lebih defensif terhadap payload imperfect
- `FinanceTab` dibuat lebih jujur terhadap paid summary
- ticket pages dibuat lebih human-readable dan tenant-friendly
- hasilnya: tenant portal tidak lagi terasa seperti alias backoffice mentah

## 2026-04-19 — Fase A Role-Based Navigation & Dashboard Dianggap Cukup Berjalan
- navigation per role sudah cukup jelas
- owner/admin/staff/tenant tidak lagi membaca surface yang sama
- route guard inti sudah lebih aman
- phase berikutnya resmi digeser ke Tenant Identity & Portal Access Simplification

## 2026-04-19 — Resource Config Cleanup Masuk Housekeeping Kecil
- `resources.ts` dibaca sebagai housekeeping kecil untuk menyelaraskan IA compact
- isu utamanya bukan blocker runtime utama lagi, tetapi internal consistency terhadap arah role-first dan embedded modules
- statusnya dapat diteruskan sebagai cleanup kecil tanpa menahan pembukaan phase berikutnya


## 2026-04-20 — Phase B Portal Access Core Freeze

### Portal summary & email clarity
- tenant detail diperkaya portal summary read-only
- email portal vs email tenant diperjelas di tenant create/edit
- honest visibility diterapkan agar UI tidak memberi fake toggle sebelum backend siap

### Tenant-context portal actions
- backend + frontend toggle portal access tenant-context selesai
- backend + frontend create portal account tenant-context selesai
- backend + frontend reset password portal tenant-context selesai
- role OWNER/ADMIN menjadi pengelola lifecycle dasar portal tenant
- tenant context kini menjadi tempat utama memahami dan mengelola portal access dasar

### Makna fase ini
- tujuan inti Phase B tenant identity & portal access dianggap cukup tertutup
- operator tidak lagi perlu meloncat ke flow users generik untuk kebutuhan portal access dasar
- phase berikutnya resmi bergeser ke Ticket Tenant-Only Redesign

## Status Terkini
**Batch 0 frontend cukup freeze, role split inti cukup berjalan, dan Phase B core portal access slice sudah freeze-ready. Next official phase = Ticket Tenant-Only Redesign.**
